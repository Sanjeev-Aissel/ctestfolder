<?php
/**
*Controller for Clinical Trials operations
*@author Ramesh B
*@since Otsuka 1.0.11
*@package application.controllers	
*@created on 03-04-2013
*
*/

class Clinical_trials_org extends Controller{
	
	var $maxScriptTime		= 86400;
	var $logFileName		= '';
	var $startTime			= '';
	var $logFile			='';
	var $logText			='';
	var $pmidBatchSize		=10;
	var $sleepTime			=2;
	var $safeTime			=10;
	
	var $logFileNamePmidSkipped		= '';
	var $logFilePmidSkipped			= '';
	var $observerEmailId	= ANALYST_EMAIL_ID;

	//Constructore
	function Clinical_trials_org(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model('clinical_trial');
		$this->load->model('clinical_trial_org');
		$this->load->library("Ajax_pagination");
		$this->load->model('common_helpers');
		$this->load->model('pubmed_org');
		$this->logFilePath		= $this->config->item('app_folder_path').'system/logs/clinical';
		
		$observerEmail =  $this->input->post("observer_email");
		if($observerEmail != null && $observerEmail != '')
			$this->observerEmailId = $observerEmail;
		if($this->session->userdata('logged_in') == 1)
			$this->observerEmailId = $this->session->userdata('email');
	}
	
	/**
	 * Processes the kols for Clinical Trials and saves related data into database
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return
	 */
	function process_clinical_trials(){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
		
		ini_set("max_execution_time",$this->maxScriptTime);			
		//get the ClinicalTrialsUnprocessed kol's
		$arrOrgDetails=$this->clinical_trial_org->getClinicalTrialsUnprocessedOrgs();
		if(sizeof($arrOrgDetails)<1){
			$this->logText	= "There are No Unprocessed KOL ids, Terminating Process..  \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Processing Unprocessed KOL ids'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			die("Sorry! There are No Unprocessed KOL ids, Terminating Process..");
		}
		$this->logText	= "Following are the Unprocessed KOL ids  \r\n";
		fwrite($this->logFile, $this->logText);
		foreach($arrOrgDetails as $arrOrgDetail){
			$this->logText	= $arrOrgDetail['id']."  \r\n";
			fwrite($this->logFile, $this->logText);
		}		
		
		$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
		fwrite($this->logFile, $this->logText);	
		//Start of loop trought each Organization , gather CTID's, get Clinical Trials, parse and save data 
		foreach($arrOrgDetails as $arrOrgDetail){
			$kolStartTime=microtime(true);			
			$this->logText	= "\r\nStarting Clinical Trials processing for KOLId ".$arrOrgDetail['id']." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			$orgId=$arrOrgDetail['id'];
			
			$arrNameCombinations = $this->pubmed_org->getOrgNameCombinations($orgId);
			$arrNameCombinations[]=$arrOrgDetail['name'];
			
			$this->logText	= "Org Name: ".$arrOrgDetail['name']."  \r\n";
			fwrite($this->logFile, $this->logText);
			
			$this->logText	= "Following are the Name combinations genarated  \r\n";
			fwrite($this->logFile, $this->logText);
			foreach($arrNameCombinations as $nameCombination){
				$this->logText	= $nameCombination."  \r\n";
				fwrite($this->logFile, $this->logText);
			}					
			//Get the list of Clinical Trials ID's for organizaton
			$this->logText	= "\r\nStarting getting CTID's  \r\n";
			fwrite($this->logFile, $this->logText);
			$arrCTIDs=array();
			$gathCTIDTime=microtime(true);

			foreach($arrNameCombinations as $orgName){
				$url = "http://clinicaltrials.gov/search?&displayxml=true&retmax=1000&spons=".$orgName;
					$content = $this ->retrieve_page_get($url);	
					if(!$content)	return false;
					//$content = str_replace(array('&lt;','&gt;'),array('<','>'),$content);
					
					//echo $content;
					$xml = new DOMDocument();
					if(!$xml->loadXML($content)){
						$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Clinical Trail Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
					}		
					
					$searchResultsObj = $xml->getElementsByTagName('search_results')->item(0);
					$idList=$searchResultsObj->getElementsByTagName('nct_id');
					foreach($idList as $idObj){
						$arrCTIDs[]=$idObj->nodeValue;					
					}
					
			}
			$this->logText	= "No of CTID's found for name '".$arrOrgDetail['name']."': ".sizeof($arrCTIDs)."\r\n";
			fwrite($this->logFile, $this->logText);
			sleep($this->sleepTime);
			
			$this->logText	= "Time taken to gather CTIDs: ".(microtime(true)-$gathCTIDTime)."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$arrUniqueCTIDs = array_unique($arrCTIDs);	
			$arrUniqueCTIDs=array_values($arrUniqueCTIDs);
			$this->logText	= "\r\nTotal No of CTIDs found after removing duplicates: ".sizeof($arrUniqueCTIDs)." \r\n";
			fwrite($this->logFile, $this->logText);
			//End of getting the Clinical trial ID's
			
			//Check for already existing Clinical Trial's and associate them with Organization
			$arrFilteredCTIDs=$this->clinical_trial_org->checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $orgId);
			$this->logText	= "Total No of CTIDs found after removing already existing Clinical Trials in database: ".sizeof($arrFilteredCTIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			//End of checking and associating already existing Clinical Trials

		
			//Get the Clinical Trial details for all the CTID's
			$this->logText	= "\r\nStart of getting the Clinical Trials details for each CTID \r\n";
			$this->logText	= "Following Clinical Trials with CTID's are parsed and saved sucessfully\r\n ";
			fwrite($this->logFile, $this->logText);
			fwrite($this->logFile, $this->logText);
			foreach($arrFilteredCTIDs as $uniqueCTID){
				$ctFetchStartTime=microtime(true);	
				$url = "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true";
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);
				$content = $this ->retrieve_page_get($url);		
				if(!$content)	return false;
				$timeTaken=microtime(true)-$ctFetchStartTime;		
				$this->logText	= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);				
				$xml = new DOMDocument();
				if(!$xml->loadXML($content)){
					$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Clinical Trail Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);	
					//continue;
					die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}			
				
				//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
				$clinicalStudys = $xml->getElementsByTagName('clinical_study');
				foreach($clinicalStudys as $clinicalStudy){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
					}
					
					$ctStartTime=microtime(true);
					//getting the parsed values for Clinical trial 
					$ctDetails=$this->parse_ct_details($clinicalStudy);					
					//echo "</br><pre>";
						
					//saves the Clinical trial details
					$ctId=$this->save_clinical_trials($ctDetails, $orgId);	
					if($ctId!=null){
						//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);						
					}else{
						$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Clinical Trail Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						continue;	
					}	
					
					//getting the parsed values for sponsers
					$arrSponsers=$this->parse_clinicle_sponsers($clinicalStudy);
					
					//saves sponser details and returns bollean value
					$isSaved=$this->clinical_trial->saveSponsers($arrSponsers, $ctId);	
					
					//getting the parsed values for Intervention
					$arrIntervention=$this->parse_clinicle_intervention($clinicalStudy);
					
					//saves Intervention details and returns bollean value
					$isSaved=$this->clinical_trial->saveInterventions($arrIntervention, $ctId);	
					
					//getting the parsed values for Keywords
					$arrKeyword=$this->parse_clinicle_keyword($clinicalStudy);
					
					//saves Keyword details and returns bollean value
					$isSaved=$this->save_keyword($arrKeyword, $ctId);	
					
					//getting the parsed values for Meshterms
					$arrMeshterms=$this->parse_clinicle_meshterms($clinicalStudy);
					
					//saves Meshterms details and returns bollean value
					$isSaved=$this->save_meshterms($arrMeshterms, $ctId);	
					
					//getting and parsed values for Investigators
					$arrInvestigators=$this->parse_clinicle_investigators($clinicalStudy);
					
					//saves $arrInvestigators details and returns bollean value
					$isSaved=$this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
				
					$timeTaken=microtime(true)-$ctStartTime;
					$this->logText	= "CTID '".$ctDetails['ct_id']."'	Time taken for: ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah Clinical Trial, parsing and saving
			$this->logText	= "End of Procesing all the CTID's \r\n";
			fwrite($this->logFile, $this->logText);		
			echo "</br>Organization Id :".$arrOrgDetail['id']." Clinical Trials Processed</br>";
			$arrOrgDetail['is_clinical_trial_processed']=1;
			$this->clinical_trial_org->updateClinicalTrialProcessedOrg($arrOrgDetail);
			$this->logText	= "Clinical Trial Processing of KOLID :".$arrOrgDetail['id']." is Completed sucessfully \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Clinical Trial Processing',
					'miscellaneous1'=>$url
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);		
		}
		// End of loop trough each kol	
	}
	
	
	/**
	 * parse the values for Clinical Trial
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function parse_ct_details($clinicalStudy,$arrOrgNameCombination=array()){
		$ctDetails = array();
		$trialName = ''; 
		$statusId = '';
		$ctId='';
		$purpose = ''; 
		$condition = '';
		$phase='';
		$officialTitle = ''; 
		$studyType = '';
		$startDate='';
		$endDate = ''; 
		$link = '';
		
		//getting the Trial Name
		$breifTitleObj= $clinicalStudy->getElementsByTagName('brief_title')->item(0);
		if($breifTitleObj !=''){
			$trialName = $breifTitleObj->nodeValue;
		}
	 	//pr($trialName);
		
		//getting the Status
		$statusObj = $clinicalStudy->getElementsByTagName('overall_status')->item(0);
		$statusName = '';
		if($statusObj!=''){
			$statusName = $statusObj->nodeValue;
			if($statusName == ''){
				$statusName = 'NotAvailable';
			}
			$statusId=$this->clinical_trial->saveStatus($statusName);
		}
		//pr($statusId);
			
		//getting the CTID
		$ctIdObj = $clinicalStudy->getElementsByTagName('id_info')->item(0);
		if($ctIdObj != ''){
			$nctIdObj = $ctIdObj->getElementsByTagName('nct_id')->item(0);
			$ctId = $nctIdObj->nodeValue;
		}
		// pr($ctId);	
		
		//getting the Purpose of Trial
		$purposeObj = $clinicalStudy->getElementsByTagName('brief_summary')->item(0);
		$textObj = $purposeObj->getElementsByTagName('textblock')->item(0);
		if($textObj !=''){
			$purpose = $textObj->nodeValue;
		}
		//pr($purpose);		
		
		//getting the Condition
		$arrCondition	= array();
		foreach($clinicalStudy->getElementsByTagName('condition') as $conditionObj){
			if($conditionObj!=''){
				$arrCondition[]=$conditionObj->nodeValue;
			}
		}
		
		//getting the Phase
		$phaseObj = $clinicalStudy->getElementsByTagName('phase')->item(0);
		if($phaseObj!=''){
			$phase = $phaseObj->nodeValue;
		}
		//pr($phase);		
		
		//getting the Official Title
		$officialTitleObj = $clinicalStudy->getElementsByTagName('official_title')->item(0);
		if($officialTitleObj!=''){
			$officialTitle=$officialTitleObj->nodeValue;
		}
		//pr($officialTitle);
		
		//getting the Study Type
		$studyTypeObj = $clinicalStudy->getElementsByTagName('study_type')->item(0);
		if($studyTypeObj!=''){
			$studyType=$studyTypeObj->nodeValue;
		}
		//echo 'StudyType</br>'; pr($studyType);	

		//getting the Start Date
		$startDateObj = $clinicalStudy->getElementsByTagName('start_date')->item(0);
		if($startDateObj!=''){
			$startDate=$startDateObj->nodeValue;
		}
		//echo 'StartDate</br>'; pr($startDate);
		
		//getting the End Date
		$endDateObj = $clinicalStudy->getElementsByTagName('completion_date')->item(0);
		if($endDateObj!=''){
			$endDate=$endDateObj->nodeValue;
		}
		//echo 'EndDate</br>';pr($endDate);
		
		$arrCollaborators		= '';
		//getting the gender
	/*	$collaboratorObj	= $clinicalStudy->getElementsByTagName('collaborator')->item(0);
		if($collaboratorObj!=''){
			$collaborator	= $collaboratorObj->getElementsByTagName('agency')->item(0)->nodeValue;
		}
	*/
		$sponsorsObj = $clinicalStudy->getElementsByTagName('sponsors')->item(0);
		$collaborators = $sponsorsObj->getElementsByTagName('collaborator');
		foreach($collaborators as $collaboratorObj){
			if($collaboratorObj!=null){
				$agencyObj = $collaboratorObj->getElementsByTagName('agency')->item(0);
				if($agencyObj!=null){							
					$arrCollaborators[]= $agencyObj->nodeValue;
				}
			}
		}
		
		//getting the gender
		$genderObj	= $clinicalStudy->getElementsByTagName('gender')->item(0);
		if($genderObj!=''){
			$gender	= $genderObj->nodeValue;
		}
		
		//getting the minimum_age
		$minimumAgeObj		= $clinicalStudy->getElementsByTagName('minimum_age')->item(0);
		if($minimumAgeObj!=''){
			$minimumAge		= $minimumAgeObj->nodeValue;
			if($minimumAge=="N/A"){
				$minimumAge	= '';
			}
		}
		
		//getting the minimum_age
		$maximumAgeObj		= $clinicalStudy->getElementsByTagName('maximum_age')->item(0);
		if($maximumAgeObj!=''){
			$maximumAge		= $maximumAgeObj->nodeValue;
			if($maximumAge=="N/A"){
				$maximumAge	= '';
			}
		}
		
		//getting the enrollment
		$enrollmentObj	= $clinicalStudy->getElementsByTagName('enrollment')->item(0);
		if($enrollmentObj!=''){
			$enrollment	= $enrollmentObj->nodeValue;
		}
		$no_of_trial_sites	= 0;
		$kolRole			= '';
		$overallOfficialObj	= $clinicalStudy->getElementsByTagName('overall_official');
		foreach($overallOfficialObj as $investigatorsObj){
			if(sizeof($arrOrgNameCombination)>0){
				$last_nameObj	= $investigatorsObj->getElementsByTagName('last_name')->item(0);
				$lastname		= explode(',',$last_nameObj->nodeValue);
				if (in_array(str_replace('.','',$lastname[0]), str_replace('  ',' ',$arrOrgNameCombination))){
					//getting the role
					$roleObj	= $investigatorsObj->getElementsByTagName('role')->item(0);
					if($roleObj!=''){
						$kolRole	= $roleObj->nodeValue;
					}
				}
			}
		}
		$locationsObj		= $clinicalStudy->getElementsByTagName('location');
		$no_of_trial_sites	= $locationsObj->length;
		//pr($locationsObj);
		//echo $locationsObj->length.'<br />'.sizeof($locationsObj);
		if(empty($kolRole)){
			foreach($locationsObj as $locationObj){
				//$no_of_trial_sites++;
				if(sizeof($arrOrgNameCombination)>0){
				//	$last_nameObj	= $locationObj->getElementsByTagName('last_name')->item(0);
					foreach($locationObj->getElementsByTagName('last_name') as $last_nameObj){
						$lastname		= explode(',',$last_nameObj->nodeValue);
						if (in_array(str_replace('.','',$lastname[0]), str_replace('  ',' ',$arrOrgNameCombination))){
							//getting the role
							$roleObj	= $locationObj->getElementsByTagName('role')->item(0);
							if($roleObj!=''){
								$kolRole	= $roleObj->nodeValue;
							}
						}
					}
				}
			}
		}
		//getting the Link
		$link="http://clinicaltrials.gov/ct2/show/$ctId";
		//echo 'Link</br>';pr($link);		
		
		//Prepare array represinting Clinical Trials details	
		$ctDetails['ct_id']				= $ctId;
		$ctDetails['trial_name']		= $trialName;
		$ctDetails['status_id']			= $statusId;
		$ctDetails['purpose']			= $purpose;
		$ctDetails['condition']			= implode(', ',$arrCondition);
		$ctDetails['phase']				= $phase;
		$ctDetails['official_title']	= $officialTitle;
		$ctDetails['study_type']		= $studyType;
		$ctDetails['start_date']		= $startDate;
		$ctDetails['end_date']			= $endDate;
		$ctDetails['collaborator']		= implode(', ',$arrCollaborators);
		$ctDetails['gender']			= $gender;
		$ctDetails['min_age']			= $minimumAge;
		$ctDetails['max_age']			= $maximumAge;
		$ctDetails['no_of_enrollees']	= $enrollment;
		$ctDetails['no_of_trial_sites']	= $no_of_trial_sites;
		$ctDetails['kol_role']			= $kolRole;
		$ctDetails['link']				= $link;
		//End of preparing array

		return $ctDetails;
	}

	/**
	 * Saves the Clinical Trials and returns the id of it
	 * @param Array $ctDetails
	 * @param Integer $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Integer
	 */
	function save_clinical_trials($ctDetails, $orgId, $isVerified = 0){					
		//save the Clinical Trials and get the Clinical Trials id
		$ctId=$this->clinical_trial->saveClinicalTrials($ctDetails);		
		//prepare the kol-to-Clinical Trials association object
		$kolClinicalTrials=array();
		$kolClinicalTrials['org_id']=$orgId;
		$kolClinicalTrials['cts_id']=$ctId;
		$kolClinicalTrials['is_deleted']=0;	
		$kolClinicalTrials['is_verified']= $isVerified;
		
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$kolClinicalTrials['client_id'] = $this->session->userdata('client_id');
		$kolClinicalTrials['user_id']   = $this->session->userdata('user_id');
		//save the kol-to-Clinical Trials record
		$isSaved=$this->clinical_trial_org->saveOrgClinicalTrials($kolClinicalTrials);
		$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_ADD, $ctId, MODULE_KOL_TRIAL, $orgId);
		//return the Clinical Trials Id	
		return $ctId;
	}	
	
	
	/**
	 * parse the values for Sponsers
	 * @param $clinicalStudy
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function parse_clinicle_sponsers($clinicalStudy){
		//getting the Sponsers
		$arrSponsers=array();
		$sponsorsObj = $clinicalStudy->getElementsByTagName('sponsors')->item(0);
		$leadSponsers=$sponsorsObj->getElementsByTagName('lead_sponsor');
		foreach($leadSponsers as $leadSponserObj){
				if($leadSponserObj!=null){	
					$leadSponser=array();
					$type='lead sponsor';
					$agency='';
					$agencyClass='';																	
					$agencyObj = $leadSponserObj->getElementsByTagName('agency')->item(0);
					if($agencyObj!=null){							
						$agency= $agencyObj->nodeValue;
					}
					$agencyClassObj = $leadSponserObj->getElementsByTagName('agency_class')->item(0);
					if($agencyClassObj!=null){							
						$agencyClass= $agencyClassObj->nodeValue;
					}
					$leadSponser['type']=$type;
					$leadSponser['agency']=$agency;
					$leadSponser['agency_class']=$agencyClass;	
					$arrSponsers[]=$leadSponser;
				}
			}
		
		$collaborators = $sponsorsObj->getElementsByTagName('collaborator');
		foreach($collaborators as $collaboratorObj){
			if($collaboratorObj!=null){	
				$collaborator=array();
				$type='collaborator';
				$agency='';
				$agencyClass='';																	
				$agencyObj = $collaboratorObj->getElementsByTagName('agency')->item(0);
				if($agencyObj!=null){							
					$agency= $agencyObj->nodeValue;
				}
				$agencyClassObj = $collaboratorObj->getElementsByTagName('agency_class')->item(0);
				if($agencyClassObj!=null){							
					$agencyClass= $agencyClassObj->nodeValue;
				}
				$collaborator['type']=$type;
				$collaborator['agency']=$agency;
				$collaborator['agency_class']=$agencyClass;	
				$arrSponsers[]=$collaborator;
			}
		}
		return $arrSponsers;	
	}
	
	/**
	 * parse the values for Interventions
	 * @param $clinicalStudy
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function parse_clinicle_intervention($clinicalStudy){
		//getting the Interventions
		$arrIntervention=array();
		$interventions = $clinicalStudy->getElementsByTagName('intervention');
		
		foreach($interventions as $interventionObj){
				if($interventionObj!=null){	
					$intervention=array();
					$type='';
					$name='';
					$description = '';	
					$armGroupLabel='';	
					$othrName='';															
					$interventionTypeObj = $interventionObj->getElementsByTagName('intervention_type')->item(0);
					if($interventionTypeObj!=null){							
						$type= $interventionTypeObj->nodeValue;
					}
					
					$interventionNameObj = $interventionObj->getElementsByTagName('intervention_name')->item(0);
					if($interventionNameObj!=null){							
						$name= $interventionNameObj->nodeValue;
					}
					
					$descriptionObj = $interventionObj->getElementsByTagName('description')->item(0);
					if($descriptionObj!=null){							
						$description= $descriptionObj->nodeValue;
					}
					
					$armGroupLabels = $interventionObj->getElementsByTagName('arm_group_label');
					$armGroupLabelValue;
					foreach ($armGroupLabels as $armGroupLabelObj){
						if($armGroupLabelObj!=null){							
						 	$armGroupLabelValue= $armGroupLabelObj->nodeValue;
						}
						$armGroupLabel=$armGroupLabel+$armGroupLabelValue+",";
					}
//					//Right now saving all the Array of Arm groups as one String
//					foreach ($armGroupLabelArr as $armGroup){
//						$armGroupLabel=$armGroupLabel+$armGroup.",";
//					}
					
					$othrNameObj = $interventionObj->getElementsByTagName('other_name')->item(0);
					if($othrNameObj!=null){							
						$othrName= $othrNameObj->nodeValue;
					}

					$intervention['type']=$type;
					$intervention['name']=$name;
					$intervention['description']=$description;	
					$intervention['arm_group_label']=$armGroupLabel;	
					$intervention['other_name']=$othrName;
					$arrIntervention[]=$intervention;
				}
				
			}
		return  $arrIntervention;
	}	

	
	/**
	 * parse the values for keywords
	 * @param $clinicalStudy
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function parse_clinicle_keyword($clinicalStudy){
		//getting the Keywords
		$arrKeyword=array();
		$keywords = $clinicalStudy->getElementsByTagName('keyword');
		foreach ($keywords as $keywordObj){
			$keywordName=array();
			if($keywordObj!=null){							
			 	$keywordName['name']= $keywordObj->nodeValue;
			}
			$arrKeyword[]=$keywordName;
		}
		return  $arrKeyword;
	}
	
	/**
	 * Saves the array of Keyword one by one
	 * @param Array $arrKeyword
	 * @param Integer $ctId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function save_keyword($arrKeyword, $ctId){
		$isSaved=false;	
		foreach($arrKeyword as $keyword){			
			$keywordId=$this->clinical_trial->saveKeyword($keyword);
			
			$ctKeyword=array();
			$ctKeyword['cts_id']=$ctId;
			$ctKeyword['keyword_id']=$keywordId;
			
			$isSaved=$this->clinical_trial->saveCtKeyword($ctKeyword);
		}
		return $isSaved;
	}
		
	/**
	 * parse the values for Meshterms
	 * @param $clinicalStudy
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function parse_clinicle_meshterms($clinicalStudy){
		//getting the Meshterms
		$arrMeshterms=array();
		//For Condition Browse
		$conditionBrowseObj = $clinicalStudy->getElementsByTagName('condition_browse')->item(0);
		if($conditionBrowseObj!=null){
			$conditionBrowse=array();
			$type='condition_browse';
			$name='';	
			$meshterms = $conditionBrowseObj->getElementsByTagName('mesh_term');
			foreach ($meshterms as $meshtermsObj){
				if($meshtermsObj!=null){							
					$name= $meshtermsObj->nodeValue;
				}	
				$conditionBrowse['term_name']=$name;
				$conditionBrowse['type']=$type;	
				$arrMeshterms[]=$conditionBrowse;					
			}			
		}
	
		//For Intervention Browse
		$interventionBrowseObj = $clinicalStudy->getElementsByTagName('intervention_browse')->item(0);
		if($interventionBrowseObj!=null){
			$interventionBrowse=array();
			$type='intervention_browse';
			$name='';	
			$meshterms = $interventionBrowseObj->getElementsByTagName('mesh_term');
			foreach ($meshterms as $meshtermsObj){
				if($meshtermsObj!=null){							
					$name= $meshtermsObj->nodeValue;
				}
				$interventionBrowse['term_name']=$name;
				$interventionBrowse['type']= $type;
				$arrMeshterms[]=$interventionBrowse;
			}
		}
		return  $arrMeshterms;
	}
	
	/**
	 * saves the given array of meshterms and assosiates them  with the given clinical trial
	 * @param $arrMeshterms
	 * @param $ctId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function save_meshterms($arrMeshterms, $ctId){
		$isSaved=false;
		foreach($arrMeshterms as $meshterms){
			$meshtermId=$this->clinical_trial->saveMeshterms($meshterms);
			$ctMeshterms=array();
			$ctMeshterms['cts_id']=$ctId;
			$ctMeshterms['term_id']=$meshtermId;
			$isSaved=$this->clinical_trial->saveCtMeshterms($ctMeshterms);
		}
		return $isSaved;
	}
	
	/**
	 * Parse the list of investigaters from the given xml data, and returns array of investigators
	 * @param $clinicalStudy
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function parse_clinicle_investigators($clinicalStudy,$arrKolNameCombination=array()){
		//getting the Investigators(
		$arrInvestigators=array();
		
		$investigators = $clinicalStudy->getElementsByTagName('overall_official');
		if($investigators!=null){
			foreach($investigators as $investigatorObj){
				if($investigatorObj!=null){
					$investigator=array();					
					$lastName='NA';
					$role='Investigator';
					$affiliation='NA';
					$lastNameObj=$investigatorObj->getElementsByTagName('last_name')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
					$roleObj=$investigatorObj->getElementsByTagName('role')->item(0);
					if($roleObj!=null)
						$role=$roleObj->nodeValue;
					$affiliationObj=$investigatorObj->getElementsByTagName('affiliation')->item(0);
					if($affiliationObj!=null)
						$affiliation=$affiliationObj->nodeValue;
					$investigator['last_name']=$lastName;
					$investigator['role']=$role;	
					$investigator['affiliation']=$affiliation;
					$arrInvestigators[$investigator['last_name']]=$investigator;
				}
			}
		}
		$overallInvestigatorObj	= $clinicalStudy->getElementsByTagName('investigator');
		foreach($overallInvestigatorObj as $investigatorsObj){
			$investigator	= array();	
			$last_nameObj	= $investigatorsObj->getElementsByTagName('last_name')->item(0);
			$roleObj		= $investigatorsObj->getElementsByTagName('role')->item(0);
			if($last_nameObj!=''){
				$investigator['last_name']	= $last_nameObj->nodeValue;
			}
			if($roleObj!=''){
				$investigator['role']		= $roleObj->nodeValue;
			}
			$arrInvestigators[$investigator['last_name']]=$investigator;
		}
		$kolnameExists	= false;
		if(sizeof($arrKolNameCombination)>0){
			foreach($arrInvestigators as $investigators){
				if (in_array(str_replace('.','',$investigator['last_name']), str_replace('  ',' ',$arrKolNameCombination))){
					$kolnameExists	= true;
				}
			}
		}
		if(!$kolnameExists){
			$investigator	= array();
			$investigator['last_name']	= $arrKolNameCombination[sizeof($arrKolNameCombination)-1];
			$investigator['role']		= 'Principal Investigator';	
			$investigator['affiliation']= '';
			$arrInvestigators[]			= $investigator;
		}
		return  $arrInvestigators;
	}
	
	/**
	 * Gets the content from the given url
	 * @param $url
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @return data Object
	 * @created on 03-04-2013
	 */
	public function retrieve_page_get($url){
		if($_SERVER['SERVER_ADDR'] == '192.168.1.15'){
			$aContext = array(
			    'http' => array(
			        'proxy' => 'tcp://192.168.1.90:808',
			        'request_fulluri' => true,
			    ),
			);		
			$cxContext = stream_context_create($aContext);
			
			$res=null;
			//if(!$res = file_get_contents($url)){
			if(!$res = file_get_contents($url, false, $cxContext)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);										
			}			
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}else{
			$data = array();
			$res = null;
			$data['status'] = false;
			if(!$res = file_get_contents($url)){
				//$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
				//fwrite($this->logFile, $this->logText);	
				//die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);
				$data['status'] = false;											
			}else{
				$data['status'] = true;
			}			
			if(!$res){	
				//echo 'Error in connecting to url'.$url;
				$data['status'] = false;
			}else{
				$data['status'] = true;
			}
			
			$data['response'] = $res;
			return $data;
		}
	}
	
	/**
	 * Process CTIDs and associates them with given organization
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function processCTIDs($orgId=''){
		$ctIds		= trim($this->input->post('ctids'));
		$arrCtIds	= array();
		$arrData	= array();
		if(!empty($orgId) && !empty($ctIds)){
			
			//Analyst App to be accessed by only Aissel users. 
			$this->common_helpers->checkUsers();
			$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/ctids_crawled';
			$this->startTime	= microtime(true);
			$this->logFileName	= $this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
			$this->logFile	= fopen($this->logFileName, "w");
			$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
			$this->logText	= "Starting Crawling of CT IDs: " . $ctIds . " for KOL Id ".$orgId."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$arrCtIds	= explode(',',$ctIds);
			//Check for already existing Clinical Trial's and associate them with kol
			$arrCtIds		= $this->clinical_trial_org->checkAndAssociateAlreadyExistClinicalTrials($arrCtIds, $orgId,1);
			$this->logText	= "Total No of CTIDs found after associating with existing trials: ".sizeof($arrCtIds)." \r\n";
			$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
			fwrite($this->logFile, $this->logText);	
			//End of checking and associating already existing Clinical Trials
			if(sizeof($arrCtIds)>0){
				foreach($arrCtIds as $key=>$ctID){
					$uniqueCTID	= trim($ctID);
					if(!empty($uniqueCTID)){
						// http://www.clinicaltrials.gov/ct2/show/NCT00038402?displayxml=true&id=NCT00038402
						$ctFetchStartTime	= microtime(true);	
						$url 				= "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true&show_locs=Y&id=$uniqueCTID";
						$this->logText		= "Url generated: ".$url."\r\n";
						fwrite($this->logFile, $this->logText);
						$content 			= $this ->retrieve_page_get($url);		
						if(!$content)	return false;
						$timeTaken			= microtime(true)-$ctFetchStartTime;		
						$this->logText		= "Time taken to fetch Clinical Trial : ".$timeTaken."\r\n";
						fwrite($this->logFile, $this->logText);				
						$xml 				= new DOMDocument();
						if(!$xml->loadXML($content)){
							$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
							fwrite($this->logFile, $this->logText);	
							//continue;
							die("Sorry! Coulndnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
						}			
						
						//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
						$clinicalStudys 	= $xml->getElementsByTagName('clinical_study');
						foreach($clinicalStudys as $clinicalStudy){
							$timeElapsed	= (microtime(true) - $this->startTime);
							$remTime		= $this->maxScriptTime-$timeElapsed;
							//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
							if($remTime<$this->safeTime){
								$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
								fwrite($this->logFile, $this->logText);	
								die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
							}
							$ctStartTime	= microtime(true);
							//getting the parsed values for Clinical trial 
							$ctDetails		= $this->parse_ct_details($clinicalStudy);					
							//saves the Clinical trial details
							$ctId			= $this->save_clinical_trials($ctDetails, $orgId);	
							if($ctId!=null){
								//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
								//fwrite($this->logFile, $this->logText);						
							}else{
								$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
								fwrite($this->logFile, $this->logText);
								continue;
							}	
							
							//getting the parsed values for sponsers
							$arrSponsers	= $this->parse_clinicle_sponsers($clinicalStudy);
							
							//saves sponser details and returns bollean value
							$isSaved		= $this->clinical_trial->saveSponsers($arrSponsers, $ctId);	
							
							//getting the parsed values for Intervention
							$arrIntervention= $this->parse_clinicle_intervention($clinicalStudy);
							
							//saves Intervention details and returns bollean value
							$isSaved		= $this->clinical_trial->saveInterventions($arrIntervention, $ctId);	
							
							//getting the parsed values for Keywords
							$arrKeyword		= $this->parse_clinicle_keyword($clinicalStudy);
							
							//saves Keyword details and returns bollean value
							$isSaved		= $this->save_keyword($arrKeyword, $ctId);	
							
							//getting the parsed values for Meshterms
							$arrMeshterms	= $this->parse_clinicle_meshterms($clinicalStudy);
							
							//saves Meshterms details and returns bollean value
							$isSaved		= $this->save_meshterms($arrMeshterms, $ctId);	
							
							//getting and parsed values for Investigators
							$arrInvestigators= $this->parse_clinicle_investigators($clinicalStudy);
							
							//saves $arrInvestigators details and returns bollean value
							$isSaved		= $this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
						
							$timeTaken		= microtime(true)-$ctStartTime;
							$this->logText	= "Time taken to process CTID '".$ctDetails['ct_id']."': ".$timeTaken."\r\n";
							$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
							fwrite($this->logFile, $this->logText);
						}
						sleep($this->sleepTime);
						$arrData['message']	= 'Completed processing';
					}
				}
				
				$this->logText	= "End of Procesing all the CTID's \r\n";
				fwrite($this->logFile, $this->logText);		
			}else{
				$arrData['message']	= 'Terminated';
			}
		}else{
			$arrData['message']	= 'KOL ID and CT ID are mandatory and should not be empty';
			$this->logText	= $arrData['message']."\r\n";
			fwrite($this->logFile, $this->logText);	
		}
		$arrData['status']	= 'success';
		$arrData['info']	= 'CT ID(s) processed is '.sizeof($arrCtIds);
		echo json_encode($arrData);
	}
	
	/**
	 * Processes the CTIDs assoicated with the organizations
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function process_ctids_only_orgs(){
		ini_set("max_execution_time",$this->maxScriptTime);
		
		//Get all the KOLs having the CTIDs only
		$arrOrgs = $this->clinical_trial_org->getClinicalTrialsUnprocessedOrgs();
		
		$this->logFileNamePmidSkipped	=$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath."/skipped/" . "ctids_skipped_orgs_".date("d-m-Y").".txt";
		$this->logFilePmidSkipped	= fopen($this->logFileNamePmidSkipped, "w");
		fwrite($this->logFilePmidSkipped, $this->logText);
		
		//Analyst App to be accessed by only Aissel users. 
		//$this->common_helpers->checkUsers();
		$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/ctids_crawled';
		$this->startTime	= microtime(true);
		$this->logFileName	= $this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
			
		if(sizeof($arrOrgs) > 0){
			//Loop trough each KOL
			foreach($arrOrgs as $arrOrgDetail){
				$orgId = $arrOrgDetail['id'];
				$this->logText	= "Starting Crawling of CT IDs for Organization Id ".$orgId."\r\n";
				fwrite($this->logFile, $this->logText);
				
				//Get the CTIDs for this KOL
				$arrCtIds = $this->clinical_trial_org->getCTIDs($orgId);
				$this->logText	= "Total No of CTIDs : ".sizeof($arrCtIds)." \r\n";
				fwrite($this->logFile, $this->logText);	
				
				//Check for already existing Clinical Trial's and associate them with kol
				$arrCtIds		= $this->clinical_trial_org->checkAndAssociateAlreadyExistClinicalTrials($arrCtIds, $orgId,1);
				$this->logText	= "Total No of CTIDs found after associating with existing trials: ".sizeof($arrCtIds)." \r\n";
				fwrite($this->logFile, $this->logText);	
				$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
				fwrite($this->logFile, $this->logText);	
				//End of checking and associating already existing Clinical Trials
				if(sizeof($arrCtIds)>0){
					foreach($arrCtIds as $key=>$ctID){
						$uniqueCTID	= trim($ctID);
						if(!empty($uniqueCTID)){
							// http://www.clinicaltrials.gov/ct2/show/NCT00038402?displayxml=true&id=NCT00038402
							$ctFetchStartTime	= microtime(true);	
							$url 				= "http://clinicaltrials.gov/ct2/show/$uniqueCTID?displayxml=true&show_locs=Y&id=$uniqueCTID";
							$this->logText		= "Url generated: ".$url."\r\n";
							fwrite($this->logFile, $this->logText);
							
							$response = $this ->retrieve_page_get($url);
							//Try once again if the response of the status is false	
							if($response['status'] == false){
								//give 2 second delay
								sleep($this->sleepTime);
								$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
								//Log Activity
								$arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Clinical Trail Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true);
								fwrite($this->logFile, $this->logText);
								//try once again
								$response = $this ->retrieve_page_get($url);
							}
							// Skipp this and log the details if still respons is false
							if($response['status'] == false){
								//log the details
								$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of CTID, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
								//Log Activity
								$arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Clinical Trail Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true);
								fwrite($this->logFile, $this->logText);
								
								$this->logText = "Recrawl : OrgId Id - ".$orgId."  : CTIDs : ".$uniqueCTID."\r\n";
								fwrite($this->logFilePmidSkipped, $this->logText);
								//continue to next step
								continue;
							}
			
							$timeTaken			= microtime(true)-$ctFetchStartTime;		
							$this->logText		= "Time taken to fetch Clinical Trial : ".$uniqueCTID."\r\n";
							fwrite($this->logFile, $this->logText);

							$xml = new DOMDocument();
							if(!$xml->loadXML($response['response'])){
								$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
								//Log Activity
								$arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Clinical Trail Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true);
								fwrite($this->logFile, $this->logText);	
								
								$response = $this ->retrieve_page_get($url);
								//Try once again if the response of the status is false	
								if($response['status'] == false){
									//give 2 second delay
									sleep($this->sleepTime);
									$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
									//Log Activity
									$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Clinical Trail Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);
									fwrite($this->logFile, $this->logText);
									//try once again
									$response = $this ->retrieve_page_get($url);
								}
								// Skipp this and log the details if still respons is false
								if($response['status'] == false){
									//log the details
									$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of CTIDs, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
									//Log Activity
									$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Clinical Trail Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);
									fwrite($this->logFile, $this->logText);
									
									$this->logText = "Recrawl : OrgId Id - ".$orgId."  : CTIDs : ".$uniqueCTID."\r\n";
									fwrite($this->logFilePmidSkipped, $this->logText);
									//continue to next step
									continue;
								}
								
								if(!$xml->loadXML($response['response'])){
									//log the details and continue
									$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of CTIDs, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
									//Log Activity
									$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Clinical Trail Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);
									fwrite($this->logFile, $this->logText);	
									
									$this->logText = "Recrawl : OrgId Id - ".$orgId."  : CTIDs : ".$uniqueCTID."\r\n";
									fwrite($this->logFilePmidSkipped, $this->logText);
									continue;
									//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
								}										
							}
			
							
							//Start Loop trough each Clinical trial, i.e for each CTID there will be one Clinical Study"
							$clinicalStudys 	= $xml->getElementsByTagName('clinical_study');
							foreach($clinicalStudys as $clinicalStudy){
								$timeElapsed	= (microtime(true) - $this->startTime);
								$remTime		= $this->maxScriptTime-$timeElapsed;
								//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
								if($remTime<$this->safeTime){
									$this->logText	= "Stopping the Clinical Trials processing, Timelimit reached.\r\n ";
									fwrite($this->logFile, $this->logText);	
									die("Sorry! Stopping the Clinical Trials processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
								}
								$ctStartTime	= microtime(true);
								$arrOrgName		= $this->kol->getOrgName($orgId);
								//get the different combinations of names
								//$arrOrgNameCombination	= $this->generate_name_combinations($arrOrgName['first_name'], $arrOrgName['middle_name'], $arrOrgName['last_name']);
								//getting the parsed values for Clinical trial 
								$ctDetails		= $this->parse_ct_details($clinicalStudy);					
								//saves the Clinical trial details
								$ctId			= $this->save_clinical_trials($ctDetails, $orgId, 1);	
								if($ctId!=null){
									//$this->logText	= "Clinical Trial with CTID:".$ctDetails['ct_id']." parsed and saved sucessfully\r\n ";
									//fwrite($this->logFile, $this->logText);						
								}else{
									$this->logText	= "Error in parsing and saving the Clinical Trial with CTID:".$ctDetails['ct_id']." \r\n ";
									//Log Activity
									$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Clinical Trail Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);
									fwrite($this->logFile, $this->logText);
									continue;
								}	
								
								//getting the parsed values for sponsers
								$arrSponsers	= $this->parse_clinicle_sponsers($clinicalStudy);
								
								//saves sponser details and returns bollean value
								$isSaved		= $this->clinical_trial->saveSponsers($arrSponsers, $ctId);	
								
								//getting the parsed values for Intervention
								$arrIntervention= $this->parse_clinicle_intervention($clinicalStudy);
								
								//saves Intervention details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInterventions($arrIntervention, $ctId);	
								
								//getting the parsed values for Keywords
								$arrKeyword		= $this->parse_clinicle_keyword($clinicalStudy);
								
								//saves Keyword details and returns bollean value
								$isSaved		= $this->save_keyword($arrKeyword, $ctId);	
								
								//getting the parsed values for Meshterms
								$arrMeshterms	= $this->parse_clinicle_meshterms($clinicalStudy);
								
								//saves Meshterms details and returns bollean value
								$isSaved		= $this->save_meshterms($arrMeshterms, $ctId);	
								
								//getting and parsed values for Investigators
								$arrInvestigators= $this->parse_clinicle_investigators($clinicalStudy,$arrOrgNameCombination);
								
								//saves $arrInvestigators details and returns bollean value
								$isSaved		= $this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);	
							
								$timeTaken		= microtime(true)-$ctStartTime;
								$this->logText	= "Time taken to process CTID '".$ctDetails['ct_id']."': ".$timeTaken."\r\n";
								$this->logText	= "\r\n------------------------------------------------------------------------- \r\n\r\n";
								fwrite($this->logFile, $this->logText);
							}
							sleep($this->sleepTime);
							$arrData['message']	= 'Completed processing';
							
						}
						
					}
						
				}else{
					$arrData['message']	= 'Terminated';
				}
				
				$arrStatusData['id'] = $orgId;
				$arrStatusData['is_clinical_trial_processed'] = 1;
				$this->clinical_trial_org->updateClinicalTrialProcessedOrg($arrStatusData);
			}
		}else{
			echo "No Unprocessed KOL ids";
			$this->logText	= "No Unprocessed KOL ids \r\n";
			fwrite($this->logFile, $this->logText);	
		}
		$this->logText	= "End of Procesing all the CTID's \r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=> $this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Clinical Trial Processing',
				'miscellaneous1'=>$url
		);
		$this->config->set_item('log_details', $arrLogDetails);
		//log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
				
		$this->logText	= "Processing Ended on: " . date("d-m-Y H:i:s") . "\r\n";
		echo $this->logText; 
		fwrite($this->logFile, $this->logText);
		
		$this->send_status_mail($this->logText);
	}
	
	/**
	 * Display the page to Add Clinical Trial manually
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function add_client_clinical_trial($orgId){
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		//$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		$arrClinicalTrialDetails	= array('id'                =>	'',
											'trial_name'		=>	'',
											'status_id'			=>	'',
											'sponsor'	 		=> 	'',
											'condition'			=> 	'',
											'intervention'	 	=> 	'',
											'phase'	 			=> 	'',
											'investigators'	 	=> 	'',
											'keyword'			=>	'',
											'meshterm'			=>	'',
											'official_title'	=>	'',
											'link'				=>	'',
											'study_type'		=>	'',
											'collaborator'		=>	'',
											'start_date'		=>	'',
											'end_date'			=>	'',
											'no_of_enrollees'	=>	'',
											'no_of_trial_sites'	=>	'',
											'min_age'			=>	'',
											'max_age'			=>	'',
											'purpose'			=>	'',
											'kol_role'			=>	'',
											'gender'			=>	''
										);
		
		$arrClinicalTrialDetails['no_of_sponsors']=1;
		$manualSponsor['id'] = '';
		$manualSponsor['sponsor'] = $arrClinicalTrialDetails['sponsor'];
		
		$arrClinicalTrialDetails['no_of_intervention']=1;
		$manualIntervention['id'] = '';
		$manualIntervention['intervention'] = $arrClinicalTrialDetails['intervention'];
		
		$arrClinicalTrialDetails['no_of_investigators']=1;
		$manualInvestigator['id'] = '';
		$manualInvestigator['investigators'] = $arrClinicalTrialDetails['investigators'];
		
		$arrClinicalTrialDetails['no_of_meshterms']=1;
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = $arrClinicalTrialDetails['meshterm'];
		
		$arrClinicalTrialDetails['no_of_keywords']=1;
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = $arrClinicalTrialDetails['keyword'];
		
		$data['arrSponsor'] 	= $manualSponsor;
		$data['arrIntervention']= $manualIntervention;
		$data['arrInvestigator']= $manualInvestigator;
		$data['arrMeshterm']	= $manualMeshterm;
		$data['arrKeyword']		= $manualKeyword;
		
		$data['arrClinicalTrial'] = $arrClinicalTrialDetails;
		$data['orgId'] = $orgId;
		
		$this->load->view('organizations/add_clinical_trials',$data);
	}
	
	/**
	 * Display the page to Add Clinical Trial manually
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function add_clinical_trial($orgId){
		$this->add_client_clinical_trial($orgId);
	}
	
	/**
	 * Saves the Manual Clinical Trial Detail to DB 
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function save_clinical_trial_manual(){
		// Getting the POST details of Clinical Trial
		$arrClinicalTrial  = array(	
									'trial_name'		=>	ucwords(trim($this->input->post('trial_name'))),
									'status_id' 		=> 	$this->input->post('status_id'),
									'condition'	 		=> 	ucwords(trim($this->input->post('condition'))),
									'phase'	 			=> 	$this->input->post('phase'),
									'study_type'	 	=> 	$this->input->post('study_type'),
									'official_title'	=> 	ucwords(trim($this->input->post('official_title'))),
									'link'	 			=> 	$this->input->post('trial_link'),
									//'kol_role'	 		=> 	$this->input->post('kol_role'),
									'collaborator'	 	=> 	ucwords(trim($this->input->post('collaborator'))),
									'purpose'	 		=> 	ucwords(trim($this->input->post('purpose'))),
									'start_date'	 	=> 	$this->input->post('start_date'),
									'end_date'	 		=> 	$this->input->post('end_date'),
									'min_age'	 		=> 	$this->input->post('min_age'),
									'max_age'	 		=> 	$this->input->post('max_age'),
									'gender'	 		=> 	$this->input->post('gender'),
									'no_of_enrollees'	=> 	$this->input->post('no_of_enrollees'),
									'no_of_trial_sites'	=> 	$this->input->post('no_of_trial_sites')
								);
			
		$arrSponsers = array();
		$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'));
		if($arrSponser['agency'] != ''){
			$arrSponsers[] = $arrSponser;
		}
		
		$arrInterventions =array();
		$arrIntervention['name']			= 	trim($this->input->post('intervention'));
		if($arrIntervention['name'] !=''){
			$arrInterventions[] = $arrIntervention;
		}
		
		$arrInvestigators = array();
		$arrInvestigator['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		if($arrInvestigator['last_name'] !=''){
			$arrInvestigators[]  = $arrInvestigator;
		}
		
		$orgId			=	$this->input->post('org_id');
		
		$arrClinicalTrial['is_manual']= 1;
		$arrClinicalTrial['ct_id'] = $this->clinical_trial->getManualCtid();
		$currentMethod	= $this->input->post('methodName');
		if($currentMethod == 'add_client_clinical_trial'){
			$ctId	= $this->clinical_trial_org->saveClinicalTrialsByClient($arrClinicalTrial,$orgId);
		}else{
			$ctId	= $this->clinical_trial_org->saveClinicalTrialsManualAndFlags($arrClinicalTrial,$orgId);
		}
		
		$this->update->insertUpdateEntry(ORG_TRIAL_ADD, $ctId, MODULE_ORG_TRIAL, $orgId);
		
		$isSaved = false;
		if($ctId){
			$isSaved = true;
		}
		
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
			$value = trim($this->input->post('sponsor'.$i));
			if($value !=''){
				$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
				$arrSponsers[] = $arrSponser;
			}else
				continue;
		}		
		//saves sponsers details and returns bollean value
		if(sizeof($arrSponsers) >=1){
			$isSaved =$this->clinical_trial->saveSponsers( $arrSponsers, $ctId);
		}
		
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
			$value = trim($this->input->post('intervention'.$i));
			if($value !=''){
				$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
				$arrInterventions[] = 	$arrIntervention;
			}else
				continue;
		}
		//saves Interventions details and returns bollean value
		if(sizeof($arrInterventions) >=1){
			$isSaved=$this->clinical_trial->saveInterventions($arrInterventions, $ctId);
		}
		
		
		
		$i=2;
		$noOfInvestigators=$this->input->post('no_of_investigators');
		for($i=2;$i<=$noOfInvestigators;$i++){
			$value = trim($this->input->post('investigators'.$i));
			if($value !=''){
				$arrInvestigator['last_name']	 			= 	trim($this->input->post('investigators'.$i));
				$arrInvestigators[] = 	$arrInvestigator;
			}else
				continue;
		}
		//saves Investigators details and returns bollean value
		if(sizeof($arrInvestigators) >=1){
			$isSaved=$this->clinical_trial->saveInvestigators($arrInvestigators, $ctId);
		}
		
		//Keywords
		
			$value = trim($this->input->post('keywords'));
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $ctId;
					$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
				}
			}
		//End
		$i=2;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=2;$i<=$noOfKeywords;$i++){
			$value = trim($this->input->post('keywords'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $ctId;
					$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
				}
			}else
				continue;
		}
		
		$value = trim($this->input->post('meshterms'));
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value;
				}
				if(!empty($meshTermId)){
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $ctId;
					$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
				}
			}
		
		$i=2;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=2;$i<=$noOfMeshterms;$i++){
			$value = trim($this->input->post('meshterms'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value;
				}
				if(!empty($meshTermId)){
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $ctId;
					$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
				}
			}else
				continue;
		}
		
		// Create an array to return the result
		$arrResult = array();
	
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $ctId;
			$arrResult['msg']			= "Successfully saved the Clinical Trial details";
			
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Saving";
		}
		
		
		if($currentMethod == 'add_client_clinical_trial'){
			//For client appplication
			redirect('organizations/view_clinical_trials/'.$orgId);
		}else{
			//For analyst appplication
			//	echo json_encode($arrResult);
			redirect("organizations/edit_organization/".$orgId."/trials");
		}
	}
	
	/**
	 * Updates the Manual Clinical Trial Detail to DB 
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function update_clinical_trial_manual(){
		$orgId	=	$this->input->post('org_id');
		// Getting the POST details of Clinical Trial
		$arrClinicalTrial  = array(	'id'                =>	$this->input->post('id'),
									'trial_name'		=>	ucwords(trim($this->input->post('trial_name'))),
									'status_id' 		=> 	$this->input->post('status_id'),
									'condition'	 		=> 	ucwords(trim($this->input->post('condition'))),
									'phase'	 			=> 	$this->input->post('phase'),
									'study_type'	 	=> 	$this->input->post('study_type'),
									'official_title'	=> 	ucwords(trim($this->input->post('official_title'))),
									'link'	 			=> 	$this->input->post('trial_link'),
									//'kol_role'	 		=> 	$this->input->post('kol_role'),
									'collaborator'	 	=> 	ucwords(trim($this->input->post('collaborator'))),
									'purpose'	 		=> 	ucwords(trim($this->input->post('purpose'))),
									'start_date'	 	=> 	$this->input->post('start_date'),
									'end_date'	 		=> 	$this->input->post('end_date'),
									'min_age'	 		=> 	$this->input->post('min_age'),
									'max_age'	 		=> 	$this->input->post('max_age'),
									'gender'	 		=> 	$this->input->post('gender'),
									'no_of_enrollees'	=> 	$this->input->post('no_of_enrollees'),
									'no_of_trial_sites'	=> 	$this->input->post('no_of_trial_sites'));
			
		$isSaved=$this->clinical_trial->updateClinicalTrialManual($arrClinicalTrial);
		$this->update->insertUpdateEntry(ORG_TRIAL_UPDATE, $arrClinicalTrial['id'], MODULE_ORG_TRIAL, $orgId);
	/*	$arrClinicalTrial['agency']	 		= 	trim($this->input->post('sponsor'));
		$arrClinicalTrial['sponsorId']	 	= 	trim($this->input->post('sponsorId'));
		if($arrClinicalTrial['sponsorId'] != ''){
			$isSaved=$this->clinical_trial->updateCtSponcers($arrClinicalTrial);
		}*/
		$this->clinical_trial->deleteSponsersOfTrialAssociation($arrClinicalTrial['id']);
		
		$arrSponsers = array();
		$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'));
		if($arrSponser['agency'] != ''){
			$arrSponsers[] = $arrSponser;
		}
		
		
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
			$value = trim($this->input->post('sponsor'.$i));
			if($value !=''){
				$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
				$arrSponsers[] = $arrSponser;
			}else
				continue;
		}		
		//saves sponsers details and returns bollean value
		if(sizeof($arrSponsers) >=1){
			$isSaved =$this->clinical_trial->saveSponsers( $arrSponsers, $arrClinicalTrial['id']);
		}
		
	//	return false;
		/*
		$i=2;
		$noOfSponsors=$this->input->post('no_of_sponsors');
		for($i=2;$i<=$noOfSponsors;$i++){
			$arrSponser['agency']	 			= 	trim($this->input->post('sponsor'.$i));
			$arrSponser['sponsorId']			= 	trim($this->input->post('sponsorId'.$i));
			$arrSponser['id'] 					= 	$arrClinicalTrial['id'];
			if($arrSponser['sponsorId'] !=''){
				//Updates sponser details and returns bollean value
				$isSaved=$this->clinical_trial->updateCtSponcers($arrSponser);
			}
		}*/
		
		/*$arrClinicalTrial['name']			= 	trim($this->input->post('intervention'));
		$arrClinicalTrial['interventionId'] = 	trim($this->input->post('interventionId'));
		if($arrClinicalTrial['interventionId'] != ''){
			$isSaved=$this->clinical_trial->updateCtIntervention($arrClinicalTrial);
		}
		
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
			$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
			$arrIntervention['interventionId']		= 	trim($this->input->post('interventionId'.$i));
			$arrIntervention['id'] 					= 	$arrClinicalTrial['id'];
			if($arrIntervention['interventionId'] != ''){
				//Updates Intervention details and returns bollean value
				$isSaved=$this->clinical_trial->updateCtIntervention($arrIntervention);
			}
		}*/
		
		$this->clinical_trial->deleteInterventionsOfTrialAssociation($arrClinicalTrial['id']);
		$arrInterventions =array();
		$arrIntervention['name']			= 	trim($this->input->post('intervention'));
		if($arrIntervention['name'] !=''){
			$arrInterventions[] = $arrIntervention;
		}
		
		$i=2;
		$noOfInterventions=$this->input->post('no_of_intervention');
		for($i=2;$i<=$noOfInterventions;$i++){
			$value = trim($this->input->post('intervention'.$i));
			if($value !=''){
				$arrIntervention['name']	 			= 	trim($this->input->post('intervention'.$i));
				$arrInterventions[] = 	$arrIntervention;
			}else
				continue;
		}
		//saves Interventions details and returns bollean value
		if(sizeof($arrInterventions) >=1){
			$isSaved=$this->clinical_trial->saveInterventions($arrInterventions, $arrClinicalTrial['id']);
		}
		
	
		
		$arrClinicalTrial['last_name']	 	= 	ucwords(trim($this->input->post('investigators')));
		$arrClinicalTrial['investigatorId'] = 	trim($this->input->post('investigatorId'));
		if($arrClinicalTrial['investigatorId'] != ''){
			$isSaved=$this->clinical_trial->updateCtInvestigator($arrClinicalTrial);
			$arrInvestigatorsToExclude[]	= $arrClinicalTrial['investigatorId'];
		}else{
			$newArrInvestigator['last_name']			= $arrClinicalTrial['last_name'];
			$newArrCtInvestigator['investigator_id']	= $this->clinical_trial->saveInvestigator($newArrInvestigator);
			$arrInvestigatorsToExclude[]				= $newArrCtInvestigator['investigator_id'];
			$newArrCtInvestigator['cts_id']				= $arrClinicalTrial['id'];
			$this->clinical_trial->saveCtInvestigator($newArrCtInvestigator);
			//echo $this->db->last_query();
			//exit();
		}
		
		$i=2;
		$noOfInvestigators=$this->input->post('no_of_investigators');
		for($i=2;$i<=$noOfInvestigators;$i++){
			$arrInvestigator['last_name']	 		= 	trim($this->input->post('investigators'.$i));
			$arrInvestigator['investigatorId']		= 	trim($this->input->post('investigatorId'.$i));
			$arrInvestigator['id'] 					= 	$arrClinicalTrial['id'];
			if($arrInvestigator['investigatorId'] != ''){
				$arrInvestigatorsToExclude[]	= $arrInvestigator['investigatorId'];
				//Updates Investigator details and returns bollean value
				$isSaved=$this->clinical_trial->updateCtInvestigator($arrInvestigator);
			}else{
				$newArrInvestigator['last_name']			= $arrInvestigator['last_name'];
				$newArrCtInvestigator['investigator_id']	= $this->clinical_trial->saveInvestigator($newArrInvestigator);
				$arrInvestigatorsToExclude[]				= $newArrCtInvestigator['investigator_id'];
			//	echo $this->db->last_query();
				$newArrCtInvestigator['cts_id']				= $arrClinicalTrial['id'];
				$this->clinical_trial->saveCtInvestigator($newArrCtInvestigator);
			//	echo $this->db->last_query();
			//	exit();
			}
		}
		$this->clinical_trial->deleteInvestigatorsAssoc($arrClinicalTrial['id'],$arrInvestigatorsToExclude);
		/*$i=1;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=1;$i<=$noOfKeywords;$i++){
			if($i==1){
				$value 				= trim($this->input->post('keywords'));
				$existingKeywordId	= trim($this->input->post('keywordId'));
			}else{
				$value 				= trim($this->input->post('keywords'.$i));
				$existingKeywordId	= trim($this->input->post('keywordId'.$i));
			}
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId) && ($keywordId!=$existingKeywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $arrClinicalTrial['id'];
					$this->clinical_trial->updateCtKeyword($existingKeywordId,$arrAssociateKeyword);
				}
			}else
				continue;
		}*/
		
		$this->clinical_trial->deleteKeywordsOfTrialAssociation($arrClinicalTrial['id']);
		$value = trim($this->input->post('keywords'));
		
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $arrClinicalTrial['id'];
					$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
				}
			}
		//End
		$i=2;
		$noOfKeywords=$this->input->post('no_of_keywords');
		for($i=2;$i<=$noOfKeywords;$i++){
			$value = trim($this->input->post('keywords'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['name'] = $value;
				if($keywordId=$this->clinical_trial->getKeywordIdByKeyword($value)){
				//	echo 'Already exists '.$value;
				}else if($keywordId=$this->clinical_trial->saveKeyword($arrData)){
				//	echo 'New Keyword '.$value;
				}
				if(!empty($keywordId)){
					$arrAssociateKeyword['keyword_id']	= $keywordId;
					$arrAssociateKeyword['cts_id']		= $arrClinicalTrial['id'];
					$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
				}
			}else
				continue;
		}
		
			//return false;
		/*
		$i=1;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=1;$i<=$noOfMeshterms;$i++){
			if($i==1){
				$value 			= trim($this->input->post('meshterms'));
				$existingTermId	= trim($this->input->post('meshtermsId'));
			}else{
				$value 			= trim($this->input->post('meshterms'.$i));
				$existingTermId	= trim($this->input->post('meshtermId'.$i));
			}
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value.'-'.$meshTermId;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value.'-'.$meshTermId;
				}
				if(!empty($meshTermId) && ($meshTermId!=$existingTermId)){
				//	echo $value.'-'.$existingTermId.'-'.$meshTermId;
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $arrClinicalTrial['id'];
					$this->clinical_trial->UpdateCtMeshterms($existingTermId,$arrAssociateMeshTerm);
				//	echo $this->db->last_query();
				}
			}else
				continue;
		}*/
		
			
		$this->clinical_trial->deleteMeshTermOfTrialAssociation($arrClinicalTrial['id']);
		$value = trim($this->input->post('meshterms'));
		if($value !=''){
			$arrData = array();
			$arrData['term_name'] = $value;
			if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
			//	echo 'Already exists '.$value;
			}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
			//	echo 'New Meshterm '.$value;
			}
			if(!empty($meshTermId)){
				$arrAssociateMeshTerm['term_id']	= $meshTermId;
				$arrAssociateMeshTerm['cts_id']		= $arrClinicalTrial['id'];
				$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
			}
		}
		
		$i=2;
		$noOfMeshterms=$this->input->post('no_of_meshterms');
		for($i=2;$i<=$noOfMeshterms;$i++){
			$value = trim($this->input->post('meshterms'.$i));
			if($value !=''){
				$arrData = array();
				$arrData['term_name'] = $value;
				if($meshTermId=$this->clinical_trial->getMeshTermIdByMeshTerm($value)){
				//	echo 'Already exists '.$value;
				}else if($meshTermId=$this->clinical_trial->saveMeshterms($arrData)){
				//	echo 'New Meshterm '.$value;
				}
				if(!empty($meshTermId)){
					$arrAssociateMeshTerm['term_id']	= $meshTermId;
					$arrAssociateMeshTerm['cts_id']		= $arrClinicalTrial['id'];
					$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
				}
			}else
				continue;
		}
		
		
		
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			=  true;
			$arrResult['lastInsertId']	=  $arrClinicalTrial['id'];
			$arrResult['msg']			=  "Successfully Updated the Clinical Trial details";
		}else{
			$arrResult['saved']			=  false;
			$arrResult['msg']			=  "Sorry! Error in Updating";
		}
		
		$currentMethod	= $this->input->post('methodName');
		if($currentMethod == 'edit_clinical_trial_manual'){
			//For client appplication
			redirect('organizations/view_clinical_trials/'.$orgId);
		}else{
			//For analyst appplication
			//	echo json_encode($arrResult);
		//	echo json_encode($arrResult);
		//redirect('kols/edit_kol/'.$this->session->userdata('kolId').'#ui-tabs-6');
		redirect("organizations/edit_organization/".$orgId."/trials");
		}
	}
	
	/**
	 * Populates the $ctId Data to the Manual form
	 * @param $ctId
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return 
	 */
	function edit_clinical_trial_manual($ctId,$orgId){
		$ctDetailsResult	= $this->clinical_trial->getClinicalTrial($ctId);
		$arrSponsors		= $this->clinical_trial->listCTSponsors($ctId);
		$arrInterventions	= $this->clinical_trial->listCTInterventions($ctId);
		$arrInvestigators	= $this->clinical_trial->listCTInvestigators($ctId);
		$arrMeshterms		= $this->clinical_trial->listCTMeshTerms($ctId);
		$arrKeywords		= $this->clinical_trial->listCTIKeyWords($ctId);
		$manualSponsors     = array();
		$manualSponsors['agency']	= '';
		$manualSponsors['id'] 		= '';
		$manualSponsors['sponsor']	= '';
		
		$manualInterventions    = array();
		$manualInterventions['name'] 	= '';
		$manualInterventions['id'] 	= '';
		$manualInterventions['intervention'] 	= '';
		
		$manualInvestigators    = array();
		$manualInvestigators['last_name'] 	= '';
		$manualInvestigators['id'] 	= '';
		$manualInvestigators['investigators'] 	= '';
		
		$manualMeshterm['id'] = '';
		$manualMeshterm['meshterms'] = '';
		
		$manualKeyword['id'] = '';
		$manualKeyword['keywords'] = '';
		
		$data['arrSponsor'] 	= $manualSponsor;
		$data['arrIntervention']= $manualIntervention;
		$data['arrInvestigator']= $manualInvestigator;
		$data['arrMeshterm']	= $manualMeshterm;
		$data['arrKeyword']		= $manualKeyword;
		
		$i=0;
		foreach ($arrMeshterms as $meshterms){
			$i++;
			if($i == 2)
				break;
			$manualMeshterms['meshterms']	= $meshterms['term_name'];
			$manualMeshterms['id'] 			= $meshterms['id'];
		}
		$i=0;
		foreach ($arrKeywords as $keywords){
			$i++;
			if($i == 2)
				break;
			$manualKeywords['keywords']  = $keywords['name'];
			$manualKeywords['id']		 = $keywords['id'];
		}
		$i=0;
		foreach ($arrSponsors as $sponsors){
			$i++;
			if($i == 2)
				break;
			$manualSponsors['sponsor']  = $sponsors['agency'];
			$manualSponsors['id'] = $sponsors['id'];
		}
		$i=0;
		foreach ($arrInterventions as $interventions){
			$i++;
			if($i == 2)
				break;
			$manualInterventions['intervention'] = $interventions['name'];
			$manualInterventions['id'] = $interventions['id'];
		}
		$i=0;
		foreach ($arrInvestigators as $investigators){
			$i++;
			if($i == 2)
				break;
			$manualInvestigators['investigators'] = $investigators['last_name'];
			$manualInvestigators['id'] = $investigators['id'];
		}
		
		$data['arrKeyword']		 			= 	$manualKeywords;
		$data['arrMultipleKeywords']		= 	$arrKeywords;
		$ctDetailsResult['no_of_keywords']	=	(sizeof($arrKeywords) !=0) ? sizeof($arrKeywords):1;
		
		$data['arrMeshterm']		 		= 	$manualMeshterms;
		$data['arrMultipleMeshterms']		= 	$arrMeshterms;
		$ctDetailsResult['no_of_meshterms']	=	(sizeof($arrMeshterms) !=0) ? sizeof($arrMeshterms):1;
		
		
		$data['arrSponsor']		 			= 	$manualSponsors;
		$data['arrMultipleSponsors']		= 	$arrSponsors;
		$ctDetailsResult['no_of_sponsors']	=	(sizeof($arrSponsors) !=0) ? sizeof($arrSponsors):1;
		
		$data['arrIntervention']		 		= 	$manualInterventions;
		$data['arrMultipleInterventions']		= 	$arrInterventions;
		$ctDetailsResult['no_of_intervention']	=	(sizeof($arrInterventions) !=0) ? sizeof($arrInterventions):1 ;
		
		$data['arrInvestigator']		 		= 	$manualInvestigators;
		$data['arrMultipleInvestigators']		= 	$arrInvestigators;
		$ctDetailsResult['no_of_investigators']	=	(sizeof($arrInvestigators) !=0) ? sizeof($arrInvestigators):1;
		
		$data['arrClinicalTrial'] = $ctDetailsResult;
		
		//Get all DropDown values for add Clinical Trial manual page
		$dropDownValues 			= 	$this->clinical_trial_manual_dropdowns();
		$data['arrStatusIds'] 		= 	$dropDownValues['arrStatusIds'];
		$data['arrPhaseIds'] 		= 	$dropDownValues['arrPhaseIds'];
		//$data['arrKOLRoles']		= 	$dropDownValues['arrKOLRoles'];
		$data['arrGenders']			= 	$dropDownValues['arrGenders'];
		
		$data['orgId'] = $orgId;
		$this->load->view('organizations/add_clinical_trials',$data);
		
	}
	
	/**
	 * Prepares the DropDoen Values for clinical trial manual Page
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function clinical_trial_manual_dropdowns(){
		$arrStatusIds = array(	4		 => COMPLETED,
								1		 => 'Recruiting',
								3 	 	 => 'Terminated',
								12		 => 'Ongoing',
								13 		 => 'Others');
		
		$arrPhaseIds = array(	'I'	 	=> 'I',
								'II'	=> 'II',
								'III' 	=> 'III',
								'IV'	=> 'IV');
		
		$arrGenders = array(	'male'	=> 'Male',
								'female'=> 'Female',
								'both' 	=> 'Both');
		
		$arrKOLRoles = array(	'Co-investigator'		=> 'Co-investigator',
								'Principal Investigator'=> 'Principal Investigator',
								'Study Director' 		=> 'Study Director',
								'Sub-investigator' 		=> 'Sub-investigator');
		
		$data['arrStatusIds']	= $arrStatusIds;
		$data['arrPhaseIds']	= $arrPhaseIds;
		$data['arrKOLRoles']	= $arrKOLRoles;
		$data['arrGenders']		= $arrGenders;
		return $data;
	}
	
	/**
	 * returns the list of Clinical Trials belongs to perticular kolId
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return JSON
	 */
	function list_clinical_trials_details($orgId,$type = 'verified'){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrClinicalTrials	= array();
		$data				= array();
		
		if($arrClinicalTrialsResults=$this->clinical_trial_org->listClinicalTrialsDetailsByType($orgId,$type)){
			foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['asoc_id'];
				$arrClinicalTrial['trial_id']	= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
				$arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
				//$arrClinicalTrial['ct_id']	= '<a href=\''. $arrClinicalTrialsResult['link'].'\' target="_new">'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrialsResult['id'];
				$arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
				
				if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
					$trialLink					= $arrClinicalTrialsResult['link'];
				$arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
				$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
				$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
				$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
				$arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];
				$arrClinicalTrial['cts_id']	= $arrClinicalTrialsResult['cts_id'];;
				$arrClinicalTrials[]			= $arrClinicalTrial;				
			}
			//pr($arrClinicalTrials);
			$count				= sizeof($arrClinicalTrials);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrClinicalTrials;  
		}
		echo json_encode($data);
	}
	
	/**
	 * Retrives the list of sponsored associated with the given clinical trial id
	 * @param $ctId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function get_sponsers($ctId){		
		$sponsersNames='';
		$arrSponsers=$this->clinical_trial->listCTSponsors($ctId);
		foreach($arrSponsers as $sponser){
			$sponserName=$sponser['agency'];
			if($sponsersNames==''){
				$sponsersNames=$sponserName;
			}else{
				$sponsersNames=$sponsersNames.",".$sponserName;
			}
		}			
		return $sponsersNames;		
	}
	
	/**
	 * Retrives the list of interventions associated with the given clinical trial id
	 * @param $ctId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function get_interventions($ctId){		
		$interventionsNames='';
		$arrInterventions=$this->clinical_trial->listCTInterventions($ctId);
		foreach($arrInterventions as $intervention){
			$interventionName=$intervention['name'];
			if($interventionsNames==''){
				$interventionsNames=$interventionName;
			}else{
				$interventionsNames=$interventionsNames.",".$interventionName;
			}
		}			
		return $interventionsNames;		
	}
	
	/**
	 * Retrives the list of investigators associated with the given clinical trial id
	 * @param $ctId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function get_investigators($ctId){		
		$investigatorsNames = '';
		$arrInvestigators=$this->clinical_trial->listCTInvestigators($ctId);
		foreach($arrInvestigators as $investigator){
			$investigatorName=$investigator['last_name'];
			if($investigatorsNames == ''){
				$investigatorsNames=$investigatorName;
			}else{
				$investigatorsNames=$investigatorsNames.",".$investigatorName;
			}
		}			
		return $investigatorsNames;		
	}
	
	/**
	 * Deletes the Clinical Trials, serves the delete from JqGrid, takes post parameters
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function delete_clinical_trials($orgId){
		$selectedRows = $_POST['slr'];
		foreach($selectedRows as $ctsId){
			$orgClinicalTrial=array();
			$orgClinicalTrial['org_id']=$orgId;
			$orgClinicalTrial['cts_id']=$ctsId;
			//$isDeleted=$this->clinical_trial->updateClinicalTrialsAsDeleted($orgClinicalTrial);
			$isDeleted=$this->clinical_trial_org->deleteOrgClinicalTrial($orgClinicalTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_TRIAL_DELETE, $ctsId, MODULE_KOL_TRIAL, $orgId);
		}		
		return true;
	}
	
	/**
	 * Deletes the Clinical Trials and organization association
	 * @param $ctsId
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function delete_clinical_trial($ctsId,$orgId){
		$orgClinicalTrial=array();
		$orgClinicalTrial['org_id']=$orgId;
		$orgClinicalTrial['cts_id']=$ctsId;
		//$isDeleted=$this->clinical_trial->updateClinicalTrialsAsDeleted($orgClinicalTrial);
		$isDeleted=$this->clinical_trial_org->deleteOrgClinicalTrial($orgClinicalTrial);
		if($isDeleted)
			return true;
		else
			return false;
	}
	
	function view_trials($id,$orgId){
		
		$data['id'] = $id;
		$data['orgId'] = $orgId;
	
		$this->load->view('clinicals/view_trials_by_parameters',$data);
	}
	
	function list_trials_details($id,$orgId){
			$investigatorDetails = $this->clinical_trial_org->getInvestigatorById($id);
			$arrIds = $this->clinical_trial_org->getAliasIds($id,$orgId,$investigatorDetails['last_name']);
			/*$arrIds = array();
			$arrIds[] = $investigatorDetails['id'];
			$arrIds[] = $investigatorDetails['alias_id'];*/
			$arrIds[] = $investigatorDetails['id'];
			$arrTrialDetails = $this->clinical_trial_org->getTrialDetails($arrIds,$orgId);
			foreach($arrTrialDetails as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['id'];
				$arrClinicalTrial['is_manual']	= $arrClinicalTrialsResult['is_manual'];
				$arrClinicalTrial['client_id']	= $arrClinicalTrialsResult['client_id'];
				//$arrClinicalTrial['ct_id']	= '<a href=\''. $arrClinicalTrialsResult['link'].'\' target="_new">'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$trialLink						= base_url()."clinical_trials/view_clinical_trial/".$arrClinicalTrial['id'];
				$arrClinicalTrial['ct_id']		= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['ct_id'].'</a>';
				$arrClinicalTrial['micro']		= '<label onClick="viewPubMicroProfile('.$arrClinicalTrialsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
				
				if($arrClinicalTrialsResult['link'] != null && $arrClinicalTrialsResult['link'] != '')
					$trialLink					= $arrClinicalTrialsResult['link'];
				$arrClinicalTrial['trial_name']	= '<a target="_new" href=\''.$trialLink.'\' >'.$arrClinicalTrialsResult['trial_name'].'</a>';
				$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
				$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
				$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
				$arrClinicalTrial['investigators']	= $this->get_investigators($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
				$arrClinicalTrials[]			= $arrClinicalTrial;				
			}
			$count				= sizeof($arrClinicalTrials);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrClinicalTrials;  
			echo json_encode($data);
	}
	
	function update_org_trial_status(){
		$status = $this->input->post('status');
		$arrOrgIds = $this->input->post('orgIds');
		
		foreach($arrOrgIds as $orgId){
			$isUpdated = $this->clinical_trial_org->changeOrgTrialStatus($orgId, $status);
		}
		
		if($isUpdated){
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Organizations Trial Status to '.$status,
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Organization',
					'kols_or_org_id' => $arrOrgIds,
					'transaction_id' =>  $arrOrgIds,
					'transaction_table_id' => ORGANIZATIONS,
					'transaction_name' => 'Update Organizations Trial Status to '.$status,
					'parent_object_id' =>  $arrOrgIds
			);
			$this->config->set_item('log_details', $arrLogDetails);
			echo "true";
		}
		else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Organizations Trial Status to '.$status,
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Organization',
					'kols_or_org_id' => $arrOrgIds,
					'transaction_id' =>  $arrOrgIds,
					'transaction_table_id' => ORGANIZATIONS,
					'transaction_name' => 'Update Organizations Trial Status to '.$status,
					'parent_object_id' =>  $arrOrgIds
			);
			$this->config->set_item('log_details', $arrLogDetails);
			echo "false";
		}
	}
	
	function clense_key_investigators(){
		//Get the array of investigator ids
		ini_set("max_execution_time",$this->maxScriptTime);
		error_reporting(E_ALL);
		$arrIds = array();
		$arrIds = $this->clinical_trial->getAllInvestigatorIds();
		echo "<br>number of Invests: ".sizeof($arrIds);
		//go trough each and clense if required
		foreach($arrIds as $investigatorId){
			//get the investigator name
			$investigatorDetails = $this->clinical_trial->getInvestigatorDetailsById($investigatorId);
			$nameInDB = $investigatorDetails['last_name'];
			echo "<br>".$nameInDB;
			$nameElements = explode(",",$nameInDB);
			//proceed only if there are more than one elements
			if($nameInDB!= '' && sizeof($nameElements) >= 2){
				//check wether the 2nd name has more name elements
				$secNameElements = explode(" ",trim($nameElements[1]));
				$arrSuffixes = array('MD','PhD','M.D.','Jr.','DO','MHS','FACC','MPH','MACP','Pharm.D.','Prof','MBChB','PharmD','ScM','FACP','MS','BS','M.P.H.','MSPH');
				$isAnyNameSaved = false;
				//Get the clinical trial id associated with it
				$ctsId = $this->clinical_trial->getInvestigatorTrialId($investigatorId);
				$i=0;
				foreach($nameElements as $name){
					if(!in_array(trim($name),$arrSuffixes)){
						$nameSuffix = '';
						if(isset($nameElements[$i+1]) && in_array(trim($nameElements[$i+1]),$arrSuffixes))
							$nameSuffix = $nameElements[$i+1];
						if($nameSuffix != '')
							$name .=",".$nameSuffix;
							
						$name = trim($name);
						if($name == '')
							continue;
						//Save name as new investigator and get the id
						$newInvestigatorDetails = array();
						$newInvestigatorDetails['last_name'] = $name;
						$newInvestigatorDetails['role'] = $investigatorDetails['role'];
						$newInvestigatorDetails['affiliation'] = $investigatorDetails['affiliation'];
						$newInvestigatorId = $this->clinical_trial->saveInvestigator($newInvestigatorDetails);
						
						//Associate the new investigator id with the ctsId
						$ctsInvestigatorDetails = array();
						$ctsInvestigatorDetails['cts_id'] = $ctsId;
						$ctsInvestigatorDetails['investigator_id'] = $newInvestigatorId;
						$isSaved = $this->clinical_trial->saveCtInvestigator($ctsInvestigatorDetails);
						if($isSaved)
							$isAnyNameSaved = true;
							
					}
					$i++;
				}
				
				//Delete the old data id clensing is happened
				if($isAnyNameSaved){
					//remove the old association of investigator id with the ctsId
					$this->clinical_trial->deleteInvestigatorAssociation($investigatorId,$ctsId);
					//remove the old invalid investigator from the db
					$this->clinical_trial->deleteInvestigator($investigatorId);
				}
			
			}
		}
	}
	
	
	/**
	 * Updates the given trials as verified
	 * @return JSON
	 * @author Ramesh B
	 * @since 
	 * @created on 14/6/2013
	 */
	function verified_clinical_trials(){
		$selectedRows = $this->input->post('trial_ids');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgTrial=array();			
			$orgTrial['is_verified']=1;
			$orgTrial['is_deleted']=0;
			$isDeleted=$this->clinical_trial_org->updateTrialAsVerified($id,$orgTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_VERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);			
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * Updates the given trials as un-verified
	 * @return JSON
	 * @author Ramesh B
	 * @since 
	 * @created on 14/6/2013
	 */
	function un_verified_clinical_trials(){
		$selectedRows = $this->input->post('trial_ids');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgTrial=array();			
			$orgTrial['is_verified']=0;
			$orgTrial['is_deleted']=0;
			$isDeleted=$this->clinical_trial_org->updateTrialAsVerified($id,$orgTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UNVERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * Updates the given trials as deleted
	 * @return JSON
	 * @author Ramesh B
	 * @since 
	 * @created on 14/6/2013
	 */
	function deleted_clinical_trials(){
		$selectedRows = $this->input->post('trial_ids');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgTrial=array();			
			$orgTrial['is_verified']=0;
			$orgTrial['is_deleted']=1;
			$isDeleted=$this->clinical_trial_org->updateTrialAsVerified($id,$orgTrial);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UNVERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	function get_unprocessed_investigators_page($orgId){
		//Get all the investigators of given org id.
		$arrInvestigators=$this->clinical_trial_org->getOrgInvestigators($orgId);
		//TODO Change the name of the variables and write the description about their usage
		//To Hold all the Processed investigators, all the investigators of kol having alias id
		$arrProcessedInvestigators=array();
		// To hold all the un processed investigators, $arrUnProcessedInvestigators=$arrInvestigators-$arrProcessedInvestigators
		$arrUnProcessedInvestigators=array();
		// To hold all the currently asigned alias investigators
		$arrPresentAliasInvestigators=array();
		//To hold all the possible alias investigators for un processed investigators, $arrPossibleAliasInvestigators=$arrUnProcessedInvestigators+$arrPresentAliasInvestigators;
		$arrPossibleAliasInvestigators=array();
		
		
		$arrProcessedInvestigators=$this->clinical_trial_org->getOrgProcessedInvestigators($orgId);
		//pr($arrProcessedInvestigators);
		//TODO What this loop does, write it
		//Prepare array of unprocessed investigators, loop trough each Org investigators, 
		//check is it has a alias id, if not then it is still un processed, i.e all the Org investigators which are un processed.
		//$arrUnProcessedInvestigators=$arrInvestigators-$arrProcessedInvestigators
		foreach($arrInvestigators as $key=>$value){
			if ( !array_key_exists($key, $arrProcessedInvestigators) ){
				$arrUnProcessedInvestigators[$value['last_name']]=$value;
			}
		}
		
		$arrPresentAliasInvestigators=$this->clinical_trial_org->getAliasInvestigators($orgId);
		
		//TODO What this loop does, write it
		//Prepare array of possible alias investigators for un processed investigators
		//$arrPossibleAliasInvestigators=$arrUnProcessedInvestigators+$arrPresentAliasInvestigators;
		//taking key as last name and first name in order to sort
		foreach($arrUnProcessedInvestigators as $key => $value){
			$arrPossibleAliasInvestigators[$value['last_name']]=$value;
		}		
		//TODO What this loop does, write it
		foreach($arrPresentAliasInvestigators as $key=>$value){
			$arrPossibleAliasInvestigators[$value['last_name']]=$value;
		}
		//pr($arrPossibleAliasInvestigators);
		/*
		 * TODO Move all the logic of getting the UnProcessed and Alias investigators to 'Model' in 2 different functions.
		 * 		Just with 2 function calls, the data should be returned from the MODEL functions
		 */
		ksort($arrPossibleAliasInvestigators,SORT_STRING);
		//Filter the unprocessed co investigators, find the similar names and exclude the name with no  similar names
		//$arrUnProcessedInvestigators=$this->pubmed->filterUnprocessedInvestigators($arrUnProcessedInvestigators);
		//$arrUnProcessedInvestigators=$this->pubmed->filterUnprocessedInvestigators($arrUnProcessedInvestigators,$arrPossibleAliasInvestigators);
		ksort($arrUnProcessedInvestigators);
		
		$data['arrUnProcessedInvestigators']=$arrUnProcessedInvestigators;
		$data['arrAliasInvestigators']=$arrPossibleAliasInvestigators;
		$this->load->view('organizations/trials/unprocessed_investigators',$data);
	}
	
	function get_processed_investigators_page($orgId){
		$arrOrgProcessedInvestigators=$this->clinical_trial_org->getOrgProcessedInvestigators($orgId);
		$data['arrOrgProcessedInvestigators']=$arrOrgProcessedInvestigators;
		$this->load->view('organizations/trials/processed_investigators',$data);
	}
	
	function associate_investigators($orgId){
		/**
		 * TODO Write the brief description about what happens, in single line.
		 * 		Move the logic to MODEL in seperate function. Just need to pass IDs and get the TRUE/FALSE
		 */
		//$arrInvestigatorsIds are the id's of co authors which are needs to be replaced(associated to) by the co auther name of $aliasId
		//With each $arrInvestigatorsIds, there will be as many co author entries as the number of publications co-authered with the same name, we have to get the authoer id's of those entries also
		//these id's will be stored in the '$matchingAuths' array, for all these co auther we have to update it's alias as $aliasId
		$arrinvestigatorIds	=$this->input->post('investigators_ids');
		$aliasId		=$this->input->post('alias_id');
		
		$investigatorDetails=$this->clinical_trial_org->getInvestigatorById($aliasId);
		$matchingInvestigators=$this->clinical_trial_org->getMatchingInvestigators($arrinvestigatorIds,$orgId);
		$aliasDeails['alias_id']=$investigatorDetails['id'];
		$aliasDeails['alias_last_name']=$investigatorDetails['last_name'];
		//foreach($arrinvestigatorIds as $authId)
			//$matchingInvestigators[$authId]=$authId;
		$matchingInvestigators=array_keys($matchingInvestigators);
		$isProcessed=$this->clinical_trial_org->associateInvestigators($matchingInvestigators,$aliasDeails);
		echo $isProcessed;
	}
	
	function disassociate_investigator($orgId){
		$investigatorId[]		=$this->input->post('investigator_id');
		$matchingInvestigators=$this->clinical_trial_org->getMatchingInvestigators($investigatorId,$orgId);
		$matchingInvestigators=array_keys($matchingInvestigators);
		//Disassociatein is same as associating the co auther with null values
		$aliasDeails['alias_id']=null;
		$aliasDeails['alias_last_name']=null;
		$isProcessed=$this->clinical_trial_org->disassociateInvestigators($matchingInvestigators,$aliasDeails);
		echo $isProcessed;
	}	
	
	
	private function send_status_mail($message, $mailId = null){
		$config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html';

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear(true);
		
		if($mailId == null)
			$mailId = $this->observerEmailId;
			
        $this->email->subject($this->logFileName);
        $this->email->from(USER,"Pub Crawling");
		$this->email->message($message);
        $this->email->to($mailId);
        $this->email->attach($this->logFileName,'attachment');
		$this->email->attach($this->logFileNamePmidSkipped,'attachment');
        $this->email->send();
	}
	
	
}