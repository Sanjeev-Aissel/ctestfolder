<?php
/**
*Model for Clinical Trial operations
*
*@package application.models
*@author Ambarish N
*@since
*@created on 10-01-11
*/

class Clinical_trial_org extends Model{

	//Constructore
	function Clinical_trial_org(){
		parent::Model();
	}
	
	/**
	 * Returns list of Clinical_trial-unprocessed org in date Asecending order
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
     function getClinicalTrialsUnprocessedOrgs(){
     	$arrOrgDetails=array();
     	$this->db->select('id,name');
     	$this->db->where('is_clinical_trial_processed','0');
     	$this->db->where('organizations.status',PROFILING);
     	$this->db->order_by("created_on", "asc");
     	$arrOrgDetailResult=$this->db->get('organizations');
	    foreach($arrOrgDetailResult->result_array() as $arrOrg){
	    			$arrOrgDetails[]= $arrOrg;
	    		}
	    return $arrOrgDetails;
     }	
     

	/**
	 * save the org-to-Clinical Trials record
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function saveOrgClinicalTrials($orgClinicalTrials){
		$orgClinicalTrials['client_id']	= INTERNAL_CLIENT_ID;
		$orgClinicalTrials['user_id']	= INTERNAL_USER_ID;
		if($this->db->insert('org_clinical_trials',$orgClinicalTrials)){
			return true;
		}else{
		     return false;
		}
	}

	/**
	 * Check whether the Clinical trial with CTID exist or not if exist it removes it from array and 
	 * get's the Clinical Trial Id of that and associates it with org
	 * @param $arrUniqueCTIDs
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $orgId,$isVerified = 0){
		$arrCount=sizeof($arrUniqueCTIDs);
		for($i=0;$i<$arrCount; $i++){
			$nctId=$arrUniqueCTIDs[$i];
			$ctId=$this->clinical_trial->checkClinicalTrialExist($nctId);
			if($ctId!=''){
				$orgClinicalTrial=array();
				$orgClinicalTrial['org_id']=$orgId;
				$orgClinicalTrial['cts_id']=$ctId;
				$orgClinicalTrial['is_verified']=$isVerified;
				$orgClinicalTrial['is_deleted']=0;
				//Save the association only if it is not exist	
				if(!$this->checkOrgCTAssociationExist($orgClinicalTrial)){		
					$isSaved=$this->saveOrgClinicalTrials($orgClinicalTrial);
				}
				unset($arrUniqueCTIDs[$i]);
			}
		}
		$arrUniqueCTIDs=array_values($arrUniqueCTIDs);
		//pr($arrUniqueCTIDs);
		return $arrUniqueCTIDs;
	}
	
	/**
	 * Check whether the given clinical trial and organizaton association exist or not
	 * @param $orgClinicalTrial
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function checkOrgCTAssociationExist($orgClinicalTrial){
		$this->db->where('org_id',$orgClinicalTrial['org_id']);
		$this->db->where('cts_id',$orgClinicalTrial['cts_id']);
		$arrCTAssoc=$this->db->get('org_clinical_trials');
		if($arrCTAssoc->num_rows()!=0){
			return true;
		} else {
			return false;
		}
	}
	

	/**
	 * Updates kol as Clinical Trial processed by setting 'is_clinical_trial_processed' to 1
	 * @param $arrOrgDetail
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function updateClinicalTrialProcessedOrg($arrOrgDetail){
		$kolDetail['is_clinical_trial_processed']=	$arrOrgDetail['is_clinical_trial_processed'];	
		$this->db->where('id', $arrOrgDetail['id']);		
		if($this->db->update('organizations', $kolDetail)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Retrives the list of CTIDs only aaocisted with given kol and whic are not crawled and associated
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function getCTIDs($orgId){
     	$arrCTIDs = array();
     	$this->db->select('ctid');
     	$this->db->where('org_id',$orgId);
     	$arrResults = $this->db->get('org_ctids');
     	if(isset($arrResults) && is_object($arrResults)){
	     	foreach($arrResults->result_array() as $row){
	     		$arrCTIDs[] = $row['ctid'];
	     	}
     	}
     	return $arrCTIDs;
     }
     
	/** Saves the Clinical Trials and returns the id of it
	 * @param Array $ctDetails
	 * @param Integer $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Integer
	 */
	function saveClinicalTrialsManualAndFlags($ctDetails, $orgId){					
		//save the Clinical Trials and get the Clinical Trials id
		$ctId=$this->clinical_trial->saveClinicalTrials($ctDetails);		
		//prepare the org-to-Clinical Trials association object
		$orgClinicalTrials=array();
		$orgClinicalTrials['org_id']=$orgId;
		$orgClinicalTrials['cts_id']=$ctId;
	//	$client_id = $this->session->userdata('client_id');	
	//	$orgClinicalTrials['user_id'] = $this->session->userdata('user_id');	
		//For manual saving Cliend id is logged client id and its verified
	//	if(isset($client_id) && $client_id != ''){
	//		$orgClinicalTrials['client_id'] = $client_id;
	//	}else{
			$orgClinicalTrials['client_id'] = INTERNAL_CLIENT_ID;
			$orgClinicalTrials['user_id'] = INTERNAL_USER_ID;
	//	}
		//save the org-to-Clinical Trials record
	//	if(!$this->checkOrgCTAssociationExist($orgClinicalTrials))
			$isSaved=$this->saveOrgClinicalTrials($orgClinicalTrials);
		//return the Clinical Trials Id	
		return $ctId;
	}
	
	/**
	 * returns the list of Clinical Trials belongs to perticular orgId passed
	 * @param $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function listClinicalTrialsDetails($orgId,$limit=null,$startFrom=null){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','org_clinical_trials.client_id','org_clinical_trials.user_id','organizations.name','organizations.cin_num'));
		$this->db->from('clinical_trials');
		$this->db->join('org_clinical_trials', 'org_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->join('organizations', 'organizations.id = org_clinical_trials.org_id','left');
		$this->db->where('org_id', $orgId);
		$this->db->where('is_verified', 1);
		
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(org_clinical_trials.client_id=$clientId or org_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		if($limit != null)
			$this->db->limit($limit,$startFrom);
			
		//$this->db->where('org_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get();
		//echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}	
		return 	$arrClinicalTrials;
	}
	
	/**
	 * Deletes the given organization and clinical trial association
	 * @param $orgClinicalTrial
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Array
	 */
	function deleteOrgClinicalTrial($orgClinicalTrial){
		$this->db->where('org_id',$orgClinicalTrial['org_id']);
		$this->db->where('cts_id',$orgClinicalTrial['cts_id']);
		if($this->db->delete('org_clinical_trials')){
			return true;
		} else {
			return false;
		}
	}
	
		
	/**
	 * insert CITD to org_ctids table
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @param $arrData
	 * @return boolean
	 * 
	 */
	function saveCTID($arrData){
		
		if($this->db->insert('org_ctids',$arrData)){
			return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	/**
	 * update is_clinical_trial_processed data
	 * @author Vinayak
	 * @since 4 april 2013
	 * @version  1.0.11
	 * @param $arrOrgDetail
	 * @return boolean
	 * 
	 */
	function updateClinicalTrialProcessedKol($arrOrgDetail){
		$kolDetail['is_clinical_trial_processed']=	$arrOrgDetail['is_clinical_trial_processed'];	
		$this->db->where('id', $arrOrgDetail['id']);		
		$this->db->update('organizations', $arrOrgDetail);		
	}
	
 	function getInvestgataorLastName($id){
     	$arrNames = array();
     	$this->db->select('last_name');
     	$this->db->where('id',$id);
     	$arrResultSet = $this->db->get('cts_investigators');
     	foreach($arrResultSet->result_array() as $row){
     		$arrNames = $row;
     	
     	}
     	return $arrNames;
     	
     }
     
	function getTrialDetails($arrIds,$orgId){
     	$this->db->distinct();
     	$this->db->select('clinical_trials.*');
     	$this->db->join('org_clinical_trials','org_clinical_trials.cts_id=clinical_trials.id','left');
     	$this->db->join('ct_investigators','ct_investigators.cts_id=org_clinical_trials.cts_id','left');
     	$this->db->join('cts_investigators','cts_investigators.id=ct_investigators.investigator_id','left');
		$this->db->where_in('ct_investigators.alias_id',$arrIds);
		$this->db->where('org_id',$orgId);
		$arrRsultSet = $this->db->get('clinical_trials');
		//echo $this->db->last_query();
		foreach($arrRsultSet->result_array() as $row){
			$arrDetails[] = $row;
		}
		return $arrDetails;
     }
     
     function getAliasIds($id,$orgId,$investigatorName){
     	$this->db->distinct();
     	$this->db->select('ct_investigators.alias_id');
     	$this->db->join('ct_investigators','ct_investigators.alias_id = cts_investigators.id','left');
     	$this->db->join('org_clinical_trials','org_clinical_trials.cts_id =  ct_investigators.cts_id','left');
		$this->db->where('cts_investigators.last_name',$investigatorName);
		$this->db->where('org_clinical_trials.org_id ',$orgId);
		$arrRsultSet = $this->db->get('cts_investigators');
		//echo $this->db->last_query();
		foreach($arrRsultSet->result_array() as $row){
			$arrDetails[] = $row['alias_id'];
		}
		return $arrDetails;
     }
	
	/**
	 * Chamges the org trial processing status to given status
	 * @author 	Ramesh B 
	 * @since	
	 * @return boolean
	 * @created 
	 */
	function changeOrgTrialStatus($orgId, $status){
		$arrOrgDetails = array();
		$arrOrgDetails['is_clinical_trial_processed'] = $status;
		$this->db->where('id',$orgId);
		if($this->db->update('organizations',$arrOrgDetails)){
			return true;
		}else{
			return false;
		}
	}
	
	function updateTrialAsVerified($id,$orgTrial){
		$this->db->where('id', $id);
     	if($this->db->update('org_clinical_trials',$orgTrial)){
			return true;
		}else{
			return false;
		} 
	}
	
	function listClinicalTrialsDetailsByType($orgId,$type){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','org_clinical_trials.cts_id','org_clinical_trials.client_id','org_clinical_trials.user_id','organizations.name','organizations.cin_num','org_clinical_trials.id as asoc_id'));
		$this->db->from('clinical_trials');
		$this->db->join('org_clinical_trials', 'org_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->join('organizations', 'organizations.id = org_clinical_trials.org_id','left');
		$this->db->where('org_id', $orgId);
		
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(org_clinical_trials.client_id=$clientId or org_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
			
		//$this->db->where('org_clinical_trials.is_deleted', 0);
		$arrClinicalTrialsResult = $this->db->get();
		//echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
				$arrClinicalTrials[]=$row;
		}	
		return 	$arrClinicalTrials;
	}
	
	/** Saves the Clinical Trials and returns the id of it
	 * @param Array $ctDetails
	 * @param Integer $orgId
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return Integer
	 */
	function saveClinicalTrialsByClient($ctDetails, $orgId){					
		//save the Clinical Trials and get the Clinical Trials id
		$ctId=$this->clinical_trial->saveClinicalTrials($ctDetails);		
		//prepare the org-to-Clinical Trials association object
		$orgClinicalTrials=array();
		$orgClinicalTrials['org_id']=$orgId;
		$orgClinicalTrials['cts_id']=$ctId;
		$orgClinicalTrials['client_id'] = $this->session->userdata('client_id');	
		$orgClinicalTrials['user_id'] = $this->session->userdata('user_id');	
		$orgClinicalTrials['is_verified'] = 1;	
		//save the org-to-Clinical Trials record
	//	if(!$this->checkOrgCTAssociationExist($orgClinicalTrials))
			$isSaved=$this->saveOrgClinicalTrialsByClient($orgClinicalTrials);
		//return the Clinical Trials Id	
		return $ctId;
	}
	
	/**
	 * save the org-to-Clinical Trials record
	 * @author Ramesh B
	 * @since Otsuka 1.0.11
	 * @created-on 03-04-2013
	 * @return boolean
	 */
	function saveOrgClinicalTrialsByClient($orgClinicalTrials){
		
		if($this->db->insert('org_clinical_trials',$orgClinicalTrials)){
			return true;
		}else{
		     return false;
		}
	}
	
	function getOrgInvestigators($orgId){
		$arrInvestigators = array();
		$this->db->select('cts_investigators.id,cts_investigators.last_name');
		$this->db->join('ct_investigators','ct_investigators.investigator_id = cts_investigators.id','left');
		$this->db->join('org_clinical_trials','ct_investigators.cts_id = org_clinical_trials.cts_id','left');
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->where('org_clinical_trials.is_deleted',0);
		$this->db->where('org_clinical_trials.is_verified',1);
		$this->db->where('last_name IS NOT NULL');
		$this->db->group_by('last_name');
		$this->db->order_by('last_name asc');
		
		$arrInvestigator = $this->db->get('cts_investigators');
		foreach($arrInvestigator->result_array() as $row){
			   	$arrInvestigators[$row['id']]=$row;
		}	
		//echo $this->db->last_query();
		return $arrInvestigators;
	}
	
	function getOrgProcessedInvestigators($orgId){
		$arrInvestigators = array();
		$this->db->select('cts_investigators.*');
		$this->db->join('ct_investigators','ct_investigators.investigator_id = cts_investigators.id','left');
		$this->db->join('org_clinical_trials','ct_investigators.cts_id = org_clinical_trials.cts_id','left');
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->where('org_clinical_trials.is_deleted',0);
		$this->db->where('org_clinical_trials.is_verified',1);
		$this->db->where('last_name IS NOT NULL');
		$this->db->where('cts_investigators.alias_id IS NOT NULL');		
		$this->db->group_by('last_name');
		$this->db->order_by('last_name asc');
		
		$arrInvestigator = $this->db->get('cts_investigators');
		foreach($arrInvestigator->result_array() as $row){
			   	$arrInvestigators[$row['id']]=$row;
		}	
		//echo $this->db->last_query();
		return $arrInvestigators;
	}
	
	function getAliasInvestigators($orgId){
		$arrProceCoAuths=array();
		$this->db->select('ali.id,ali.last_name');
		$this->db->join('ct_investigators','cts_investigators.id=ct_investigators.investigator_id','left');
		$this->db->join('clinical_trials','ct_investigators.cts_id=clinical_trials.id','left');
		$this->db->join('org_clinical_trials','clinical_trials.id=org_clinical_trials.cts_id','left');
		$this->db->join('cts_investigators as ali','cts_investigators.alias_id=ali.id','left');
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->where('org_clinical_trials.is_deleted',0);
		$this->db->where('org_clinical_trials.is_verified',1);
		$this->db->where('cts_investigators.alias_id IS NOT NULL');
		$this->db->group_by('cts_investigators.alias_id');
		$this->db->order_by('cts_investigators.last_name asc');
		$arrCOAuth = $this->db->get('cts_investigators');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrProceCoAuths[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrProceCoAuths;
	}
	
	function getInvestigatorById($investigatorId){
		$coInvestigatorDetails=array();
		$this->db->where('id',$investigatorId);
		$result	=$this->db->get('cts_investigators');
		foreach($result->result_array() as $row){
			$coInvestigatorDetails=$row;
		}
		return $coInvestigatorDetails;
	}
	
	function getMatchingInvestigators($arrInvestigatorIds,$orgId){
		//Get the name details of all the co authoer id in the '$arrInvestigatorIds', and get the all the co-authors having the same name details for given given kolId
		$arrInvestigatoros=array();
		$arrInvestigatorIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrInvestigatorIds);
		
		$this->db->select('cts_investigators.id,cts_investigators.last_name');
		$this->db->join('ct_investigators','cts_investigators.id=ct_investigators.investigator_id','left');
		$this->db->join('clinical_trials','ct_investigators.cts_id=clinical_trials.id','left');
		$this->db->join('org_clinical_trials','clinical_trials.id=org_clinical_trials.cts_id','left');
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->where('org_clinical_trials.is_deleted',0);
		$this->db->where('org_clinical_trials.is_verified',1);
		$this->db->where('cts_investigators.last_name IN (SELECT last_name FROM cts_investigators WHERE id IN ('.$arrInvestigatorIds.'))');
		$this->db->order_by('cts_investigators.last_name');
		
		$arrCOAuth = $this->db->get('cts_investigators');
		//echo $this->db->last_query();
		foreach($arrCOAuth->result_array() as $row){
			   	$arrInvestigatoros[$row['id']]=$row;
		}	
		return $arrInvestigatoros;
	}
	
	function associateInvestigators($matchingInvestigators,$aliasDeails){
	$isSavedToInvestigatorTable=false;
		
		$this->db->where_in('id',$matchingInvestigators);
		if($this->db->update('cts_investigators', $aliasDeails)){
			$isSavedToInvestigatorTable=true;
		} else {
			$isSavedToInvestigatorTable= false;
		}
		
		if($isSavedToInvestigatorTable){
			$aliasId['alias_id']=$aliasDeails['alias_id'];
			$this->db->where_in('investigator_id',$matchingInvestigators);
			if($this->db->update('ct_investigators', $aliasId)){
				return true;
			} else {
				return false;
			}
		}
		else {
			return false;
		}
		//echo $this->db->last_query();
	}
	
	function disassociateInvestigators($matchingInvestigators,$aliasDeails){
		$isSavedToInvestigatorTable=false;
		
		$this->db->where_in('id',$matchingInvestigators);
		if($this->db->update('cts_investigators', $aliasDeails)){
			$isSavedToInvestigatorTable=true;
		} else {
			$isSavedToInvestigatorTable= false;
		}
		
		if($isSavedToInvestigatorTable){
			$matchingInvestigatorIds=$this->common_helpers->convertArrayToCommaSeparatedElements($matchingInvestigators);
			$arrResults=$this->db->query("UPDATE ct_investigators SET alias_id=investigator_id WHERE investigator_id IN($matchingInvestigatorIds)");
			//pr($arrResults);
			return true;
		}else {
			return false;
		}
	}
	
}